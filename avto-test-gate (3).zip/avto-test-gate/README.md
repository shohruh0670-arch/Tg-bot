# AvtoTest — Telegram mini app

Foydalanuvchi test ishlaydi, to'g'ri javob uchun pul oladi, do'stlarini taklif qiladi va pulini kartaga yechadi.
Bot, mini app va admin panel bitta loyihada. Tashqi kutubxonalar yo'q (`npm install` shart emas), Node.js 20+ yetarli.

## Imkoniyatlar

- **Test**: rasm + savol + 3 ta javob. To'g'ri topsa yashil oyna: «Sizga berildi +24 000 so'm, Jami hisobingiz …», keyin avtomatik keyingi savol. Xato bo'lsa ham avtomatik o'tadi.
- **Pul yechish**: tugma bosilganda avval **majburiy obuna** tekshiriladi → keyin **N ta do'st taklif qilish** sharti → keyin karta va summa so'raladi.
- **Takliflarim**: shaxsiy havola, «Do'stlarni taklif qilish» tugmasi, taklif qilinganlar ro'yxati.
- **Referal bonusi**: do'st havola orqali kirsa, taklif qilganga pul tushadi va bot xabar yuboradi: «Do'stingiz … qo'shildi, sizga … so'm berildi».
- **Reyting**: haftalik / oylik / umumiy.
- **Admin panel** (mini app ichida): ref soni, ref bonus, to'g'ri javob mukofoti (min–max, tasodifiy), minimal summa; kanallar (ommaviy / zayavka / oddiy havola); savollar (rasm bilan); to'lov so'rovlari.

## Railway'ga joylash

1. **GitHub**: shu papkadagi barcha fayllarni yangi repozitoriyga yuklang.
2. **Railway** → New Project → Deploy from GitHub repo → repozitoriyni tanlang.
3. **Variables** bo'limiga kiriting:
   - `BOT_TOKEN` — @BotFather bergan token
   - `ADMIN_ID` — o'zingizning Telegram ID raqamingiz (bir nechta bo'lsa vergul bilan: `111,222`)
4. **Volume**: servis ustida o'ng tugma → Attach Volume → Mount path: `/data`.
   Barcha ma'lumotlar (`db.json`, savol rasmlari) shu yerda saqlanadi va qayta deploy qilinganda o'chmaydi.
5. **Domen**: Settings → Networking → **Generate Domain**. Port so'ralsa, Railway bergan `PORT` ishlatiladi (odatda 8080).
6. Domen yaratilgach servisni **Redeploy** qiling — bot mini app manzilini o'zi oladi va menyu tugmasini o'zi o'rnatadi.

`WEBAPP_URL` va `DATA_DIR` ni yozish shart emas: Railway'ning `RAILWAY_PUBLIC_DOMAIN` va `RAILWAY_VOLUME_MOUNT_PATH` o'zgaruvchilari avtomatik ishlatiladi. Boshqa hostingda ularni qo'lda kiriting (`.env.example` ga qarang).

> Muhim: servis **1 nusxada** (1 replica) ishlashi kerak. Bitta token bilan ikkita nusxa ishlasa, Telegram yangilanishlarni bermaydi.

ID raqamingizni bilmasangiz: botga `/id` yozing.

## Admin panel

Botga `/admin` yozing yoki mini app → Hisobim → **Admin** tugmasi.

### Majburiy obuna kanallari

| Tur | Nima kiritiladi | Qanday tekshiriladi |
|---|---|---|
| **Ommaviy** | `@kanal_nomi` | Haqiqiy obuna tekshiriladi. Bot kanalda **admin** bo'lishi shart. |
| **Zayavka** | Kanal ID (`-100…`) + zayavka havolasi | Foydalanuvchi qo'shilish so'rovini yuborsa, bajarilgan hisoblanadi. Bot kanalda **admin** bo'lishi shart. |
| **Oddiy havola** | Nom + istalgan havola | Tekshirilmaydi; havola ochilsa, bajarilgan hisoblanadi. |

Kanal ID raqamini bilish uchun botni kanalga admin qiling — bot sizga ID raqamini o'zi yuboradi.
Zayavka havolasi: kanal → Havolalar → yangi havola → «Qo'shilish so'rovlari»ni yoqing.

### To'lovlar

Foydalanuvchi so'rov yuborganda summa balansidan ushlanadi va adminga tugmali xabar keladi.
«To'landi» — pulni kartaga o'zingiz o'tkazganingizdan keyin bosing. «Rad etish» — pul foydalanuvchiga qaytadi.
Bot pulni o'zi o'tkazmaydi.

## Lokal ishga tushirish va sinov

```bash
BOT_TOKEN=... ADMIN_ID=... WEBAPP_URL=https://... node src/index.js
npm test   # soxta Telegram serveri bilan 54 ta avtomatik sinov (token kerak emas)
```

## Tuzilishi

```
src/index.js     — ishga tushirish
src/config.js    — o'zgaruvchilar (BOT_TOKEN, ADMIN_ID, ...)
src/db.js        — JSON baza (Volume ichida)
src/telegram.js  — Bot API va initData imzosini tekshirish
src/logic.js     — test, referal, obuna, pul yechish
src/bot.js       — bot buyruqlari va xabarlar
src/http.js      — mini app serveri va API
src/seed.js      — namuna savollar
public/          — mini app (index.html, app.css, app.js, signs/)
```

## Eslatmalar

- Har bir savol uchun har bir foydalanuvchiga bir marta pul beriladi. Savollar tugasa, admin paneldan yangisini qo'shing.
- Ichida 10 ta oson savol bor; admin paneldan o'zgartirish va yangisini qo'shish mumkin.
- To'g'ri javob mukofoti admin panelda **Minimal** va **Maksimal** qilib yoziladi (boshlang'ich: 10 000 – 30 000 so'm); har bir to'g'ri javobga shu oraliqdan tasodifiy summa beriladi.
- Referal bonusi faqat botga **birinchi marta** kirgan foydalanuvchi uchun beriladi.
