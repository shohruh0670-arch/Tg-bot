'use strict';
// Oddiy va ishonchli JSON ma'lumotlar bazasi.
// Fayl Volume ichida saqlanadi: <DATA_DIR>/db.json (rasmlar: <DATA_DIR>/img)
const fs = require('fs');
const path = require('path');
const seedQuestions = require('./seed');

const SEED_VERSION = 3;

const DEFAULTS = {
  settings: {
    // to'g'ri javob mukofoti: har safar shu oraliqdan tasodifiy summa beriladi (so'm)
    rewardMin: 10000,
    rewardMax: 30000,
    refBonus: 5000, // bitta taklif qilingan do'st uchun (so'm)
    refRequired: 5, // pul yechish uchun kerakli do'stlar soni
    minWithdraw: 20000, // minimal yechish summasi (so'm)
    startText: '', // /start xabari (bo'sh bo'lsa, standart matn ishlatiladi)
  },
  users: {},
  channels: [],
  questions: [],
  withdrawals: [],
  joinReq: {}, // { chatId: { userId: 1 } } — zayavka yuborganlar
  broadcasts: [], // reklamalar tarixi va statistikasi
  adState: {}, // { adminId: { btnText, btnUrl } } — reklama xabari kutilmoqda
  seq: { q: 0, ch: 0, w: 0, b: 0 },
  seeded: false,
  seedVersion: 0,
};

const SAVE_MS = Math.max(1000, Number(process.env.SAVE_INTERVAL_MS) || 15000);
const BAK_MS = 10 * 60 * 1000;

class DB {
  constructor(dir) {
    this.dir = dir;
    this.file = path.join(dir, 'db.json');
    this.imgDir = path.join(dir, 'img');
    fs.mkdirSync(this.imgDir, { recursive: true });
    this.data = this._load();
    this._timer = null;
    this._dirty = false;
  }

  _load() {
    let data = null;
    for (const f of [this.file, this.file + '.bak']) {
      try {
        if (fs.existsSync(f)) {
          data = JSON.parse(fs.readFileSync(f, 'utf8'));
          break;
        }
      } catch (e) {
        console.error('[db] faylni o\'qib bo\'lmadi:', f, e.message);
      }
    }
    const base = JSON.parse(JSON.stringify(DEFAULTS));
    if (!data || typeof data !== 'object') data = base;
    for (const k of Object.keys(base)) if (data[k] === undefined) data[k] = base[k];
    // Eski versiyadan o'tish: yagona 'reward' bo'lsa, min = max = reward
    if (data.settings && data.settings.reward !== undefined && data.settings.rewardMin === undefined) {
      data.settings.rewardMin = data.settings.rewardMax = Number(data.settings.reward) || 0;
    }
    data.settings = Object.assign({}, base.settings, data.settings);
    delete data.settings.reward;
    data.seq = Object.assign({}, base.seq, data.seq);
    // Boshlang'ich savollar: bazada hali yo'q bo'lganlari bir marta qo'shiladi
    if ((data.seedVersion || 0) < SEED_VERSION) {
      const from = data.seedVersion || 0;
      const have = new Set(data.questions.map((q) => q.image || q.text));
      for (const sq of seedQuestions) {
        // faqat bazaning joriy versiyasidan keyin qo'shilgan savollar yoziladi
        if ((sq.v || 2) <= from || have.has(sq.image || sq.text)) continue;
        data.seq.q += 1;
        data.questions.push({ id: data.seq.q, text: sq.text, options: sq.options.slice(), correct: sq.correct, image: sq.image });
      }
      data.seedVersion = SEED_VERSION;
      data.seeded = true;
    }
    // Savol matnlaridagi tuzatishlar (har safar tekshiriladi, takror qo'llanmaydi)
    for (const [from, to] of seedQuestions.fixes || []) {
      for (const q of data.questions) {
        if (q.text === from) q.text = to;
        q.options = q.options.map((o) => (o === from ? to : o));
      }
    }
    return data;
  }

  nextId(kind) {
    this.data.seq[kind] = (this.data.seq[kind] || 0) + 1;
    return this.data.seq[kind];
  }

  // Saqlash: baza katta bo'lganda (100 ming foydalanuvchi) har o'zgarishda yozish serverni
  // qotirib qo'yadi. Shuning uchun o'zgarishlar yig'ilib, SAVE_MS da bir marta, fon rejimida yoziladi.
  save() {
    this._dirty = true;
    if (this._timer || this._writing) return;
    this._timer = setTimeout(() => {
      this._timer = null;
      this._writeAsync();
    }, SAVE_MS);
  }

  async _writeAsync() {
    if (this._writing || !this._dirty) return;
    this._writing = true;
    this._dirty = false;
    const tmp = this.file + '.tmp';
    const gen = this._gen || 0;
    try {
      const json = JSON.stringify(this.data);
      await fs.promises.writeFile(tmp, json);
      // Zaxira nusxa har 10 daqiqada bir marta yangilanadi
      if (Date.now() - (this._lastBak || 0) > BAK_MS && fs.existsSync(this.file)) {
        await fs.promises.copyFile(this.file, this.file + '.bak');
        this._lastBak = Date.now();
      }
      // Shu orada flush() yangiroq nusxani yozgan bo'lsa, uni eski nusxa bilan almashtirmaymiz
      if ((this._gen || 0) === gen) await fs.promises.rename(tmp, this.file);
    } catch (e) {
      this._dirty = true;
      console.error('[db] saqlashda xato:', e.message);
    } finally {
      this._writing = false;
      if (this._dirty) this.save();
    }
  }

  // Darhol, sinxron saqlash — faqat server to'xtayotganda chaqiriladi
  flush() {
    if (this._timer) {
      clearTimeout(this._timer);
      this._timer = null;
    }
    if (!this._dirty && !this._writing) return;
    this._dirty = false;
    this._gen = (this._gen || 0) + 1;
    const tmp = this.file + '.flush.tmp';
    try {
      fs.writeFileSync(tmp, JSON.stringify(this.data));
      fs.renameSync(tmp, this.file);
    } catch (e) {
      this._dirty = true;
      console.error('[db] saqlashda xato:', e.message);
    }
  }
}

module.exports = DB;
