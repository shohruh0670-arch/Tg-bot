'use strict';
const cfg = require('./config');
const DB = require('./db');
const createTelegram = require('./telegram');
const createLogic = require('./logic');
const createBot = require('./bot');
const createHttp = require('./http');
const createBroadcast = require('./broadcast');

if (!cfg.botToken) {
  console.error('XATO: BOT_TOKEN kiritilmagan. Railway → Variables bo’limiga BOT_TOKEN qo’shing.');
  process.exit(1);
}
if (!cfg.adminIds.length) {
  console.warn('OGOHLANTIRISH: ADMIN_ID kiritilmagan — admin panel hech kimga ochilmaydi.');
}

const db = new DB(cfg.dataDir);
const rt = { botUsername: '', botId: 0 }; // ishga tushganda getMe orqali to'ldiriladi
const tg = createTelegram(cfg);
const logic = createLogic({ db, tg, cfg, rt });
const bc = createBroadcast({ db, tg, cfg, rt, logic });
const bot = createBot({ db, tg, cfg, rt, logic, bc });
const web = createHttp({ db, tg, cfg, rt, logic, bc });

console.log(`[app] ma’lumotlar papkasi: ${cfg.dataDir}`);
console.log(`[app] mini app manzili: ${cfg.webappUrl || '(sozlanmagan)'}`);

web.start()
  .then(() => bot.start())
  .then(() => bc.resume()); // to'xtab qolgan reklama bo'lsa, davom ettiriladi

function shutdown() {
  console.log('[app] to’xtatilmoqda, ma’lumotlar saqlanmoqda...');
  bot.stop();
  db.flush();
  web.server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 1500).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
process.on('unhandledRejection', (e) => console.error('[app] unhandledRejection:', e));
process.on('uncaughtException', (e) => {
  console.error('[app] uncaughtException:', e);
  db.flush();
});
