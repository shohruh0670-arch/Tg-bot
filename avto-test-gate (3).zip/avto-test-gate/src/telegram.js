'use strict';
// Telegram Bot API bilan ishlash (tashqi kutubxonasiz, Node'ning o'z fetch'i orqali)
const crypto = require('crypto');

function createTelegram(cfg) {
  const base = `${cfg.telegramApi}/bot${cfg.botToken}`;

  async function call(method, params = {}, timeoutMs = 20000) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(`${base}/${method}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
        signal: ctrl.signal,
      });
      const json = await res.json().catch(() => null);
      if (!json || !json.ok) {
        const err = new Error((json && json.description) || `Telegram xatosi (${res.status})`);
        err.code = json && json.error_code;
        err.retryAfter = json && json.parameters && json.parameters.retry_after;
        throw err;
      }
      return json.result;
    } finally {
      clearTimeout(timer);
    }
  }

  // Xato bo'lsa ham dasturni to'xtatmaydigan xabar yuborish
  async function send(chatId, text, extra = {}) {
    try {
      return await call('sendMessage', Object.assign({ chat_id: chatId, text, parse_mode: 'HTML', disable_web_page_preview: true }, extra));
    } catch (e) {
      console.warn(`[tg] ${chatId} ga xabar yuborilmadi: ${e.message}`);
      return null;
    }
  }

  // Mini app'dan kelgan initData imzosini tekshirish
  function verifyInitData(initData, maxAgeSec = 86400) {
    if (!initData || typeof initData !== 'string') return null;
    let params;
    try {
      params = new URLSearchParams(initData);
    } catch (e) {
      return null;
    }
    const hash = params.get('hash');
    if (!hash) return null;
    params.delete('hash');
    const dataCheck = [...params.entries()]
      .map(([k, v]) => `${k}=${v}`)
      .sort()
      .join('\n');
    const secret = crypto.createHmac('sha256', 'WebAppData').update(cfg.botToken).digest();
    const calc = crypto.createHmac('sha256', secret).update(dataCheck).digest('hex');
    const a = Buffer.from(calc, 'hex');
    const b = Buffer.from(String(hash), 'hex');
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    const authDate = Number(params.get('auth_date')) || 0;
    if (maxAgeSec && Date.now() / 1000 - authDate > maxAgeSec) return null;
    let user = null;
    try {
      user = JSON.parse(params.get('user') || 'null');
    } catch (e) {
      return null;
    }
    if (!user || !user.id) return null;
    return { user, startParam: params.get('start_param') || '' };
  }

  return { call, send, verifyInitData };
}

module.exports = createTelegram;
