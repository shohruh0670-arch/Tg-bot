'use strict';
// Telegram bot: /start, referal, admin tugmalari, zayavkalarni qayd etish (long polling)

const DEFAULT_START =
  '👋 Salom, <b>{name}</b>!\n\n' +
  '🚗 <b>AvtoTest</b> — yo’l harakati qoidalari bo’yicha test ishlang va pul ishlang.\n\n' +
  '✅ Har bir to’g’ri javob: <b>{reward}</b>\n' +
  '👥 Har bir taklif qilingan do’st: <b>{refBonus}</b>\n' +
  '💳 Hisobingiz: <b>{balance}</b>';

function createBot({ db, tg, cfg, rt, logic, bc }) {
  const { fmt, esc } = logic;
  let running = false;
  let offset = 0;

  function startKeyboard(u) {
    const rows = [];
    // style: success — yashil, danger — qizil tugma
    if (cfg.webappUrl) rows.push([{ text: '🚗 Testni boshlash', web_app: { url: cfg.webappUrl }, style: 'success' }]);
    if (rt.botUsername) rows.push([{ text: '👥 Do’stlarni taklif qilish', url: logic.shareUrl(u), style: 'danger' }]);
    return { inline_keyboard: rows };
  }

  const GATE_TEXT =
    '🚗 Test ishlashni boshlash uchun <b>AvtoTest</b> kanallariga obuna bo’ling.\n\n' +
    '❗️ Bu siz uchun muhim.\n\n' +
    'Obuna bo’lgach, «✅ Tekshirish» tugmasini bosing 👇';

  // Hali obuna bo'linmagan kanallar. Oddiy havola (Instagram, sayt va h.k.) bot chatida
  // tekshirib bo'lmaydi, shuning uchun u to'siq bo'lmaydi.
  async function pendingChannels(u) {
    if (!db.data.channels.length) return [];
    const subs = await logic.checkSubs(u);
    return subs.filter((c) => c.type !== 'link' && !c.ok);
  }
  function gateKeyboard(pending) {
    const rows = pending.map((c, i) => [{ text: `📢 Kanal ${i + 1}`, url: c.url }]);
    rows.push([{ text: '✅ Tekshirish', callback_data: 'sub:check', style: 'success' }]);
    return { inline_keyboard: rows };
  }

  async function onStart(msg, payload) {
    const m = /^ref_?(\d+)$/.exec(payload || '');
    const { user } = logic.ensureUser(msg.from, m ? Number(m[1]) : null);
    const pending = await pendingChannels(user);
    if (pending.length) return sendStart(msg.chat.id, GATE_TEXT, gateKeyboard(pending));
    return sendWelcome(msg.chat.id, user);
  }

  // Obuna tasdiqlangach chiqadigan asosiy /start xabari (mini app tugmasi bilan)
  async function sendWelcome(chatId, user) {
    const s = db.data.settings;
    const tpl = (s.startText || '').trim() ? s.startText : DEFAULT_START;
    const vars = {
      name: esc(user.name),
      reward: logic.rewardLabel(s),
      refBonus: fmt(s.refBonus),
      refRequired: String(s.refRequired),
      balance: fmt(user.balance),
    };
    let text = tpl.replace(/\{(name|reward|refBonus|refRequired|balance)\}/g, (_, k) => vars[k]);
    if (!cfg.webappUrl) {
      text += '\n\n⚠️ Mini app manzili sozlanmagan.';
      if (cfg.isAdmin(user.id)) text += ' Railway’da domen yarating (Settings → Networking → Generate Domain) yoki WEBAPP_URL o’zgaruvchisini kiriting va qayta ishga tushiring.';
    }
    await sendStart(chatId, text, startKeyboard(user));
  }

  async function onSubCheck(cq) {
    const { user } = logic.ensureUser(cq.from, null);
    const pending = await pendingChannels(user);
    const chatId = cq.message ? cq.message.chat.id : cq.from.id;
    if (pending.length) {
      await tg
        .call('answerCallbackQuery', { callback_query_id: cq.id, text: 'Hali barcha kanallarga obuna bo’lmadingiz. Obuna bo’lib, qayta tekshiring.', show_alert: true })
        .catch(() => {});
      // Ro'yxatda faqat qolgan kanallar ko'rinadi
      if (cq.message) {
        await callStyled('editMessageReplyMarkup', { chat_id: chatId, message_id: cq.message.message_id }, gateKeyboard(pending)).catch(() => {});
      }
      return;
    }
    await tg.call('answerCallbackQuery', { callback_query_id: cq.id, text: '✅ Obuna tasdiqlandi' }).catch(() => {});
    if (cq.message) await tg.call('deleteMessage', { chat_id: chatId, message_id: cq.message.message_id }).catch(() => {});
    await sendWelcome(chatId, user);
  }

  // ---------- /start mediasi: golos, video, GIF, rasm yoki dumaloq video ----------
  const MEDIA = {
    voice: ['sendVoice', 'voice', '🎤 golos'],
    video: ['sendVideo', 'video', '🎬 video'],
    animation: ['sendAnimation', 'animation', '🎞 GIF'],
    photo: ['sendPhoto', 'photo', '🖼 rasm'],
    video_note: ['sendVideoNote', 'video_note', '🔘 dumaloq video'],
  };
  const waitingMedia = new Set(); // /startmedia yozib, media yuborishi kutilayotgan adminlar

  function plainKeyboard(kb) {
    return { inline_keyboard: kb.inline_keyboard.map((row) => row.map((b) => { const c = Object.assign({}, b); delete c.style; return c; })) };
  }
  // Rangli tugmani qabul qilmaydigan holat uchun: xato bo'lsa rangsiz tugma bilan qayta yuboradi
  async function callStyled(method, params, kb) {
    try {
      return await tg.call(method, Object.assign({}, params, { reply_markup: kb }));
    } catch (e) {
      if (e.code === 429) {
        // Telegram "juda tez" desa (masalan, reklama ketayotganda) kutib, qayta yuboradi
        await new Promise((r) => setTimeout(r, (Math.min(e.retryAfter || 2, 30) + 1) * 1000));
        return tg.call(method, Object.assign({}, params, { reply_markup: kb }));
      }
      if (e.code !== 400) throw e;
      return tg.call(method, Object.assign({}, params, { reply_markup: plainKeyboard(kb) }));
    }
  }
  async function sendText(chatId, text, kb) {
    try {
      await callStyled('sendMessage', { chat_id: chatId, text, parse_mode: 'HTML', disable_web_page_preview: true }, kb);
    } catch (e) {
      console.warn(`[tg] ${chatId} ga xabar yuborilmadi: ${e.message}`);
    }
  }
  async function sendStart(chatId, text, kb) {
    const media = db.data.settings.startMedia;
    const def = media && MEDIA[media.type];
    if (!def) return sendText(chatId, text, kb);
    const base = { chat_id: chatId, [def[1]]: media.fileId };
    try {
      // Matn media ostida (caption) chiqadi. Dumaloq videoda va 1024 belgidan uzun matnda
      // caption bo'lmaydi — matn alohida xabar bo'lib, tugmalar bilan keladi.
      if (media.type !== 'video_note' && text.length <= 1024) {
        await callStyled(def[0], Object.assign({ caption: text, parse_mode: 'HTML' }, base), kb);
        return;
      }
      await tg.call(def[0], base);
    } catch (e) {
      console.warn(`[start] media yuborilmadi (${media.type}): ${e.message}`);
    }
    return sendText(chatId, text, kb);
  }

  async function onStartMedia(msg, arg) {
    const s = db.data.settings;
    if (/^(off|ochir|o'chir|o’chir|yoq)$/i.test(arg)) {
      waitingMedia.delete(msg.from.id);
      delete s.startMedia;
      db.save();
      return tg.send(msg.chat.id, '✅ /start mediasi olib tashlandi. Endi faqat matn chiqadi.');
    }
    waitingMedia.add(msg.from.id);
    const cur = s.startMedia && MEDIA[s.startMedia.type] ? `Hozirgi: ${MEDIA[s.startMedia.type][2]}` : 'Hozir media qo’yilmagan';
    return tg.send(
      msg.chat.id,
      `🎬 <b>/start mediasi</b>\n\n${cur}.\n\n` +
        'Endi golos, video, GIF, rasm yoki dumaloq videoni yuboring — u /start xabarining tepasida, matn va tugmalar esa ostida chiqadi.\n\n' +
        'Olib tashlash: <code>/startmedia off</code>\nBekor qilish: /bekor'
    );
  }
  // Admin media yuborsa saqlaydi. true — xabar shu yerda qayta ishlangan
  async function captureStartMedia(msg) {
    if (!waitingMedia.has(msg.from.id)) return false;
    if (/^\//.test((msg.text || '').trim())) {
      // boshqa buyruq yozilsa kutish bekor bo'ladi; /startmedia bundan mustasno
      if (!/^\/startmedia\b/i.test(msg.text.trim())) waitingMedia.delete(msg.from.id);
      if (/^\/bekor\b/i.test(msg.text.trim())) {
        await tg.send(msg.chat.id, 'Bekor qilindi.');
        return true;
      }
      return false;
    }
    let found = null;
    if (msg.voice) found = { type: 'voice', fileId: msg.voice.file_id };
    else if (msg.animation) found = { type: 'animation', fileId: msg.animation.file_id };
    else if (msg.video) found = { type: 'video', fileId: msg.video.file_id };
    else if (msg.video_note) found = { type: 'video_note', fileId: msg.video_note.file_id };
    else if (msg.photo && msg.photo.length) found = { type: 'photo', fileId: msg.photo[msg.photo.length - 1].file_id };
    if (!found) {
      await tg.send(msg.chat.id, '❌ Golos, video, GIF, rasm yoki dumaloq video yuboring. Bekor qilish: /bekor');
      return true;
    }
    waitingMedia.delete(msg.from.id);
    db.data.settings.startMedia = found;
    db.save();
    await tg.send(msg.chat.id, `✅ Saqlandi: ${MEDIA[found.type][2]}. Tekshirish uchun /start bosing.`);
    return true;
  }

  async function onRef(msg) {
    const { user } = logic.ensureUser(msg.from, null);
    const s = db.data.settings;
    await sendText(
      msg.chat.id,
      `👥 <b>Takliflarim</b>\n\n` +
        `Taklif qilgan do’stlaringiz: <b>${user.invited.length} ta</b>\n` +
        `Har bir do’st uchun: <b>${fmt(s.refBonus)}</b>\n\n` +
        `🔗 Sizning havolangiz:\n${esc(logic.refLink(user))}`,
      startKeyboard(user)
    );
  }

  async function onAdmin(msg) {
    if (!cfg.isAdmin(msg.from.id)) return;
    logic.ensureUser(msg.from, null);
    const users = Object.keys(db.data.users).length;
    const pending = db.data.withdrawals.filter((w) => w.status === 'pending').length;
    const kb = cfg.webappUrl ? { inline_keyboard: [[{ text: '⚙️ Admin panelni ochish', web_app: { url: cfg.webappUrl + '/?admin=1' } }]] } : undefined;
    await tg.send(
      msg.chat.id,
      `⚙️ <b>Admin panel</b>\n\n👤 Foydalanuvchilar: <b>${users}</b>\n💸 Kutilayotgan to’lovlar: <b>${pending}</b>` +
        (cfg.webappUrl ? '' : '\n\n⚠️ WEBAPP_URL sozlanmagan — panel ochilmaydi.'),
      kb ? { reply_markup: kb } : {}
    );
  }

  async function onMessage(msg) {
    if (!msg.from || msg.from.is_bot || !msg.chat || msg.chat.type !== 'private') return;
    // Admin reklama xabarini yuborayotgan bo’lsa, uni reklama moduli qabul qiladi
    if (cfg.isAdmin(msg.from.id) && (await captureStartMedia(msg))) return;
    if (cfg.isAdmin(msg.from.id) && (await bc.onAdminMessage(msg))) return;
    const text = (msg.text || '').trim();
    const cmd = /^\/(\w+)(?:@\w+)?(?:\s+(.*))?$/.exec(text);
    if (cmd) {
      const name = cmd[1].toLowerCase();
      if (name === 'start') return onStart(msg, (cmd[2] || '').trim());
      if (name === 'ref' || name === 'taklif') return onRef(msg);
      if (name === 'admin') return onAdmin(msg);
      if (name === 'startmedia' && cfg.isAdmin(msg.from.id)) return onStartMedia(msg, (cmd[2] || '').trim());
      if (name === 'reklama' && cfg.isAdmin(msg.from.id)) return bc.begin(msg.from.id, '', '');
      if (name === 'id') return tg.send(msg.chat.id, `Sizning ID raqamingiz: <code>${msg.from.id}</code>`);
    }
    return onStart(msg, '');
  }

  async function onCallback(cq) {
    const data = cq.data || '';
    if (data === 'sub:check') return onSubCheck(cq);
    const ad = /^b:(send|cancel):(\d+)$/.exec(data);
    if (ad) {
      if (!cfg.isAdmin(cq.from.id)) {
        return tg.call('answerCallbackQuery', { callback_query_id: cq.id, text: 'Ruxsat yo’q', show_alert: true }).catch(() => {});
      }
      let res;
      try {
        res = bc.onCallback(ad[1], Number(ad[2]));
      } catch (e) {
        res = 'ℹ️ ' + e.message;
      }
      await tg.call('answerCallbackQuery', { callback_query_id: cq.id }).catch(() => {});
      if (cq.message) {
        await tg.call('editMessageText', { chat_id: cq.message.chat.id, message_id: cq.message.message_id, text: res }).catch(() => {});
      }
      return;
    }
    const m = /^w:(pay|rej):(\d+)$/.exec(data);
    if (!m) return tg.call('answerCallbackQuery', { callback_query_id: cq.id }).catch(() => {});
    if (!cfg.isAdmin(cq.from.id)) {
      return tg.call('answerCallbackQuery', { callback_query_id: cq.id, text: 'Ruxsat yo’q', show_alert: true }).catch(() => {});
    }
    let note;
    try {
      const w = logic.processWithdrawal(Number(m[2]), m[1] === 'pay' ? 'pay' : 'reject');
      note = w.status === 'paid' ? '✅ To’landi' : '❌ Rad etildi (pul qaytarildi)';
    } catch (e) {
      note = 'ℹ️ ' + e.message;
    }
    await tg.call('answerCallbackQuery', { callback_query_id: cq.id, text: note }).catch(() => {});
    if (cq.message) {
      const old = cq.message.text || '';
      await tg
        .call('editMessageText', {
          chat_id: cq.message.chat.id,
          message_id: cq.message.message_id,
          text: `${old}\n\n${note}`,
        })
        .catch(() => {});
    }
  }

  function onJoinRequest(jr) {
    if (!jr.chat || !jr.from) return;
    const key = String(jr.chat.id);
    if (!db.data.joinReq[key]) db.data.joinReq[key] = {};
    // Yangi zayavka kunlik statistikaga qo'shiladi (takroriy zayavka sanalmaydi)
    if (!db.data.joinReq[key][jr.from.id]) logic.dailyAdd(require('./logic').dayKey(), 'zay');
    db.data.joinReq[key][jr.from.id] = Date.now();
    db.save();
  }

  async function onMyChatMember(upd) {
    const chat = upd.chat;
    const st = upd.new_chat_member && upd.new_chat_member.status;
    if (!chat) return;
    if (chat.type === 'private') {
      // foydalanuvchi botni blokladi yoki blokdan chiqardi
      const u = db.data.users[chat.id];
      if (u) {
        u.blocked = st === 'kicked';
        db.save();
      }
      return;
    }
    if (st === 'administrator') {
      for (const adminId of cfg.adminIds) {
        await tg.send(
          adminId,
          `✅ Bot admin qilindi: <b>${esc(chat.title || '')}</b>\n` +
            `🆔 Chat ID: <code>${chat.id}</code>` +
            (chat.username ? `\n🔗 @${esc(chat.username)}` : '') +
            `\n\nEndi uni admin panel → Kanallar bo’limida qo’shishingiz mumkin.`
        );
      }
    }
  }

  async function handleUpdate(u) {
    try {
      if (u.message) await onMessage(u.message);
      else if (u.callback_query) await onCallback(u.callback_query);
      else if (u.chat_join_request) onJoinRequest(u.chat_join_request);
      else if (u.my_chat_member) await onMyChatMember(u.my_chat_member);
    } catch (e) {
      console.error('[bot] update xatosi:', e);
    }
  }

  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const MAX_ACTIVE = 40; // bir vaqtda qayta ishlanadigan yangilanishlar
  let active = 0;

  async function setup() {
    const me = await tg.call('getMe');
    rt.botUsername = me.username;
    rt.botId = me.id;
    console.log(`[bot] @${me.username} ishga tushdi`);
    await tg.call('deleteWebhook', { drop_pending_updates: false }).catch(() => {});
    await tg
      .call('setMyCommands', {
        commands: [
          { command: 'start', description: 'Botni ishga tushirish' },
          { command: 'ref', description: 'Takliflarim va havolam' },
        ],
      })
      .catch(() => {});
    if (cfg.webappUrl) {
      await tg
        .call('setChatMenuButton', { menu_button: { type: 'web_app', text: 'AvtoTest', web_app: { url: cfg.webappUrl } } })
        .catch((e) => console.warn('[bot] menyu tugmasi o’rnatilmadi:', e.message));
    } else {
      console.warn('[bot] WEBAPP_URL yo’q — mini app tugmasi ko’rsatilmaydi. Railway’da domen yarating.');
    }
  }

  async function poll() {
    running = true;
    while (running) {
      try {
        const updates = await tg.call(
          'getUpdates',
          { offset, timeout: 25, allowed_updates: ['message', 'callback_query', 'chat_join_request', 'my_chat_member'] },
          40000
        );
        for (const u of updates) {
          offset = u.update_id + 1;
          // Yangilanishlar parallel qayta ishlanadi: bitta foydalanuvchining obuna tekshiruvi
          // (Telegram'ga so'rov) boshqalarning /start javobini kuttirib qo'ymaydi.
          while (active >= MAX_ACTIVE) await sleep(20);
          active += 1;
          handleUpdate(u).finally(() => { active -= 1; });
        }
      } catch (e) {
        if (!running) break;
        if (e.name !== 'AbortError') console.warn('[bot] getUpdates xatosi:', e.message);
        await sleep(e.retryAfter ? e.retryAfter * 1000 : 3000);
      }
    }
  }

  async function start() {
    for (;;) {
      try {
        await setup();
        break;
      } catch (e) {
        console.error('[bot] Telegram’ga ulanib bo’lmadi (BOT_TOKEN to’g’rimi?):', e.message);
        await sleep(5000);
      }
    }
    poll();
  }

  return { start, stop: () => (running = false), handleUpdate };
}

module.exports = createBot;
