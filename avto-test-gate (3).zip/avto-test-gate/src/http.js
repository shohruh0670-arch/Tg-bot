'use strict';
// HTTP server: mini app fayllari + API (foydalanuvchi va admin)
const http = require('http');
const fs = require('fs');
const path = require('path');
const { AppError } = require('./logic');

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.json': 'application/json; charset=utf-8',
};
const MAX_BODY = 4 * 1024 * 1024;
const MAX_IMAGE = 1.5 * 1024 * 1024;

function createHttp({ db, tg, cfg, rt, logic, bc }) {
  const d = () => db.data;

  function sendJson(res, status, obj) {
    const body = JSON.stringify(obj);
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
    res.end(body);
  }

  function readBody(req) {
    return new Promise((resolve, reject) => {
      let size = 0;
      const chunks = [];
      req.on('data', (c) => {
        size += c.length;
        if (size > MAX_BODY) {
          reject(new AppError('So’rov hajmi juda katta'));
          req.destroy();
          return;
        }
        chunks.push(c);
      });
      req.on('end', () => {
        if (!chunks.length) return resolve({});
        try {
          const j = JSON.parse(Buffer.concat(chunks).toString('utf8'));
          resolve(j && typeof j === 'object' ? j : {});
        } catch (e) {
          reject(new AppError('Noto’g’ri so’rov'));
        }
      });
      req.on('error', reject);
    });
  }

  function serveFile(res, baseDir, relPath, cache) {
    const full = path.normalize(path.join(baseDir, relPath));
    if (full !== baseDir && !full.startsWith(baseDir + path.sep)) {
      res.writeHead(403);
      return res.end();
    }
    fs.stat(full, (err, st) => {
      if (err || !st.isFile()) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('Topilmadi');
      }
      const ext = path.extname(full).toLowerCase();
      res.writeHead(200, {
        'Content-Type': MIME[ext] || 'application/octet-stream',
        'Content-Length': st.size,
        'Cache-Control': cache || 'no-cache',
      });
      fs.createReadStream(full).pipe(res);
    });
  }

  // ---- Avtorizatsiya: Telegram initData imzosi ----
  function auth(req) {
    const init = req.headers['x-init-data'];
    const v = tg.verifyInitData(Array.isArray(init) ? init[0] : init);
    if (v) {
      const m = /^ref_?(\d+)$/.exec(v.startParam || '');
      return logic.ensureUser(v.user, m ? Number(m[1]) : null).user;
    }
    if (cfg.devMode && req.headers['x-dev-user']) {
      const id = Number(req.headers['x-dev-user']);
      if (id > 0) return logic.ensureUser({ id, first_name: 'Sinov', last_name: String(id) }, null).user;
    }
    return null;
  }

  function publicSettings() {
    const s = d().settings;
    return { rewardMin: s.rewardMin, rewardMax: s.rewardMax, rewardLabel: logic.rewardLabel(s), refBonus: s.refBonus, refRequired: s.refRequired, minWithdraw: s.minWithdraw };
  }

  function meView(u) {
    return {
      id: u.id,
      name: u.name,
      username: u.username,
      balance: u.balance,
      correct: u.correct,
      wrong: u.wrong,
      refCount: u.invited.length,
      rank: logic.rankOf(u),
      tx: u.tx.slice(0, 20),
    };
  }

  // ---- Admin yordamchi funksiyalari ----
  function intField(v, min, max, label) {
    const n = Math.floor(Number(v));
    if (!Number.isFinite(n) || n < min || n > max) throw new AppError(`${label}: ${min} dan ${max} gacha son kiriting`);
    return n;
  }

  function normUrl(raw) {
    let u = String(raw || '').trim();
    if (!u) return '';
    if (u.startsWith('@')) u = 'https://t.me/' + u.slice(1);
    else if (/^t\.me\//i.test(u)) u = 'https://' + u;
    if (!/^https?:\/\/[^\s]+$/i.test(u)) throw new AppError('Havola noto’g’ri. Masalan: https://t.me/kanal');
    return u;
  }

  async function assertBotAdmin(chatId) {
    let m;
    try {
      m = await tg.call('getChatMember', { chat_id: chatId, user_id: rt.botId }, 8000);
    } catch (e) {
      throw new AppError('Bot bu kanalda admin emas. Avval botni kanalga admin qiling.');
    }
    if (m.status !== 'administrator' && m.status !== 'creator') {
      throw new AppError('Bot bu kanalda admin emas. Avval botni kanalga admin qiling.');
    }
  }

  async function addChannel(b) {
    const type = String(b.type || '');
    let title = String(b.title || '').trim().slice(0, 80);
    const ch = { id: db.nextId('ch'), type, title: '', url: '', chatId: '' };

    if (type === 'public') {
      // Ommaviy kanal: @username yoki https://t.me/username
      const raw = String(b.chat || '').trim();
      const m = /^(?:https?:\/\/)?(?:t\.me\/|@)?([A-Za-z][A-Za-z0-9_]{3,})\/?$/.exec(raw.replace(/^https?:\/\/t\.me\//i, ''));
      if (!m) throw new AppError('Kanal username’ini kiriting. Masalan: @kanal_nomi');
      const username = m[1];
      let chat;
      try {
        chat = await tg.call('getChat', { chat_id: '@' + username }, 8000);
      } catch (e) {
        throw new AppError(`@${username} topilmadi. Username to’g’riligini tekshiring.`);
      }
      await assertBotAdmin(chat.id);
      ch.chatId = String(chat.id);
      ch.url = 'https://t.me/' + username;
      ch.title = title || chat.title || '@' + username;
    } else if (type === 'request') {
      // Zayavka (so'rovli) kanal: chat ID + zayavka havolasi
      const chatId = String(b.chat || '').trim();
      if (!/^-?\d{5,}$/.test(chatId)) throw new AppError('Kanal ID raqamini kiriting. Masalan: -1001234567890');
      ch.url = normUrl(b.url);
      if (!ch.url) throw new AppError('Zayavka havolasini kiriting. Masalan: https://t.me/+AbCdEf...');
      let chat;
      try {
        chat = await tg.call('getChat', { chat_id: chatId }, 8000);
      } catch (e) {
        throw new AppError('Kanal topilmadi. ID to’g’riligini va bot kanalda admin ekanini tekshiring.');
      }
      await assertBotAdmin(chat.id);
      ch.chatId = String(chat.id);
      ch.title = title || chat.title || 'Kanal';
    } else if (type === 'link') {
      // Oddiy havola: obuna tekshirilmaydi, faqat ochilgani hisoblanadi
      ch.url = normUrl(b.url);
      if (!ch.url) throw new AppError('Havolani kiriting');
      if (!title) throw new AppError('Nomini kiriting');
      ch.title = title;
    } else {
      throw new AppError('Kanal turi noto’g’ri');
    }
    d().channels.push(ch);
    db.save();
    return ch;
  }

  function removeImage(image) {
    if (image && image.startsWith('/img/')) {
      const f = path.join(db.imgDir, path.basename(image));
      fs.unlink(f, () => {});
    }
  }

  function saveImage(dataUrl, qid) {
    const m = /^data:image\/(png|jpeg|jpg|webp);base64,([A-Za-z0-9+/=]+)$/.exec(String(dataUrl || ''));
    if (!m) throw new AppError('Rasm formati noto’g’ri (PNG, JPG yoki WEBP bo’lsin)');
    const buf = Buffer.from(m[2], 'base64');
    if (buf.length > MAX_IMAGE) throw new AppError('Rasm hajmi 1.5 MB dan oshmasin');
    const ext = m[1] === 'jpeg' ? 'jpg' : m[1];
    const name = `q${qid}_${Date.now()}.${ext}`;
    fs.writeFileSync(path.join(db.imgDir, name), buf);
    return '/img/' + name;
  }

  function saveQuestion(b) {
    const text = String(b.text || '').trim().slice(0, 500);
    if (!text) throw new AppError('Savol matnini kiriting');
    const options = Array.isArray(b.options) ? b.options.map((o) => String(o || '').trim().slice(0, 200)) : [];
    if (options.length !== 3 || options.some((o) => !o)) throw new AppError('3 ta javob variantini to’ldiring');
    const correct = intField(b.correct, 0, 2, 'To’g’ri javob');
    let q = b.id ? d().questions.find((x) => x.id === Number(b.id)) : null;
    if (b.id && !q) throw new AppError('Savol topilmadi');
    const isNew = !q;
    if (isNew) q = { id: db.nextId('q'), text: '', options: [], correct: 0, image: '' };
    if (b.imageData) {
      const img = saveImage(b.imageData, q.id);
      removeImage(q.image);
      q.image = img;
    } else if (b.removeImage) {
      removeImage(q.image);
      q.image = '';
    }
    q.text = text;
    q.options = options;
    q.correct = correct;
    if (isNew) d().questions.push(q);
    db.save();
    return q;
  }

  function adminState() {
    const users = Object.values(d().users);
    const today = require('./logic').dayKey();
    const dayStart = Date.now() - 86400000;
    return {
      stats: {
        users: users.length,
        newToday: users.filter((u) => u.joinedAt >= dayStart).length,
        activeToday: users.filter((u) => u.days[today]).length,
        totalBalance: users.reduce((s, u) => s + u.balance, 0),
        totalPaid: d().withdrawals.filter((w) => w.status === 'paid').reduce((s, w) => s + w.amount, 0),
        pending: d().withdrawals.filter((w) => w.status === 'pending').length,
        questions: d().questions.length,
        refs: users.reduce((s, u) => s + u.invited.length, 0),
        blocked: users.filter((u) => u.blocked).length,
      },
      settings: Object.assign({ rewardLabel: logic.rewardLabel(d().settings) }, d().settings),
      channels: d().channels,
      questions: d().questions,
      withdrawals: d().withdrawals.slice(0, 100),
      broadcasts: bc.list(),
      webappUrl: cfg.webappUrl,
      botUsername: rt.botUsername || '',
    };
  }

  // ---- API yo'llari ----
  const routes = {
    'GET /api/me': async (u) => ({
      user: meView(u),
      settings: publicSettings(),
      isAdmin: cfg.isAdmin(u.id),
      botUsername: rt.botUsername || '',
      refLink: logic.refLink(u),
      shareUrl: logic.shareUrl(u),
    }),

    'GET /api/question': async (u) => logic.nextQuestion(u),

    'POST /api/answer': async (u, b) => {
      const r = logic.answer(u, b.qid, b.option);
      // 3 ta to'g'ri javobdan keyin, yangi kanal bo'lsa va obuna bo'lmagan bo'lsa — majburiy oyna
      return Object.assign(r, { next: logic.nextQuestion(u) });
    },

    'GET /api/rating': async (u, b, q) => {
      const p = q.get('period');
      return logic.rating(p === 'w' || p === 'm' ? p : 'a', u.id);
    },

    'GET /api/refs': async (u) => {
      const s = d().settings;
      return {
        link: logic.refLink(u),
        shareUrl: logic.shareUrl(u),
        count: u.invited.length,
        required: s.refRequired,
        bonus: s.refBonus,
        earned: u.invited.reduce((sum, x) => sum + (x.bonus || 0), 0),
        list: u.invited.slice(0, 200).map((x) => ({ name: x.name, at: x.at, bonus: x.bonus })),
      };
    },

    'POST /api/withdraw/check': async (u) => logic.withdrawStatus(u),

    'POST /api/link-open': async (u, b) => {
      const ch = d().channels.find((c) => c.id === Number(b.id));
      if (ch && ch.type === 'link') {
        u.opened[ch.id] = 1;
        db.save();
      }
      return {};
    },

    'POST /api/withdraw': async (u, b) => {
      const r = await logic.createWithdrawal(u, b.amount, b.card);
      return { id: r.withdrawal.id, balance: r.balance };
    },

    // ---- Admin ----
    'GET /api/admin/state': async () => adminState(),
    'GET /api/admin/stats': async () => logic.adminStats(),

    'POST /api/admin/settings': async (u, b) => {
      const s = d().settings;
      const rMin = intField(b.rewardMin, 0, 10000000, 'Minimal mukofot');
      const rMax = intField(b.rewardMax, 0, 10000000, 'Maksimal mukofot');
      if (rMax < rMin) throw new AppError('Maksimal mukofot minimaldan kichik bo’lmasligi kerak');
      s.refBonus = intField(b.refBonus, 0, 10000000, 'Referal bonusi');
      s.refRequired = intField(b.refRequired, 0, 1000, 'Kerakli do’stlar soni');
      s.minWithdraw = intField(b.minWithdraw, 0, 100000000, 'Minimal yechish summasi');
      s.rewardMin = rMin;
      s.rewardMax = rMax;
      if (b.startText !== undefined) s.startText = String(b.startText || '').slice(0, 1500);
      db.save();
      return adminState();
    },

    'POST /api/admin/channel': async (u, b) => {
      await addChannel(b);
      return adminState();
    },

    'POST /api/admin/channel/delete': async (u, b) => {
      const i = d().channels.findIndex((c) => c.id === Number(b.id));
      if (i < 0) throw new AppError('Kanal topilmadi');
      d().channels.splice(i, 1);
      db.save();
      return adminState();
    },

    'POST /api/admin/question': async (u, b) => {
      saveQuestion(b);
      return adminState();
    },

    'POST /api/admin/question/delete': async (u, b) => {
      const i = d().questions.findIndex((x) => x.id === Number(b.id));
      if (i < 0) throw new AppError('Savol topilmadi');
      removeImage(d().questions[i].image);
      d().questions.splice(i, 1);
      db.save();
      return adminState();
    },

    // Reklama: panelda tugma sozlanadi, xabarning o'zi bot chatida yuboriladi
    'POST /api/admin/broadcast/start': async (u, b) => {
      await bc.begin(u.id, b.btnText, b.btnUrl);
      return {};
    },

    'POST /api/admin/broadcast/stop': async (u, b) => {
      bc.cancel(b.id);
      return adminState();
    },

    'POST /api/admin/withdrawal': async (u, b) => {
      logic.processWithdrawal(b.id, b.action === 'pay' ? 'pay' : 'reject');
      return adminState();
    },
  };

  async function handleApi(req, res, url) {
    const key = `${req.method} ${url.pathname}`;
    const handler = routes[key];
    if (!handler) return sendJson(res, 404, { ok: false, error: 'Topilmadi' });
    try {
      const user = auth(req);
      if (!user) return sendJson(res, 401, { ok: false, error: 'Ilovani Telegram bot orqali oching' });
      if (url.pathname.startsWith('/api/admin/') && !cfg.isAdmin(user.id)) {
        return sendJson(res, 403, { ok: false, error: 'Ruxsat yo’q' });
      }
      const body = req.method === 'POST' ? await readBody(req) : {};
      const result = await handler(user, body, url.searchParams);
      sendJson(res, 200, Object.assign({ ok: true }, result));
    } catch (e) {
      if (e instanceof AppError) return sendJson(res, 400, { ok: false, error: e.message });
      console.error('[api] xato:', key, e);
      sendJson(res, 500, { ok: false, error: 'Serverda xatolik yuz berdi' });
    }
  }

  const server = http.createServer((req, res) => {
    let url;
    try {
      url = new URL(req.url, 'http://localhost');
    } catch (e) {
      res.writeHead(400);
      return res.end();
    }
    let pathname;
    try {
      pathname = decodeURIComponent(url.pathname);
    } catch (e) {
      res.writeHead(400);
      return res.end();
    }

    if (pathname === '/health') {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      return res.end('ok');
    }
    if (pathname.startsWith('/api/')) return handleApi(req, res, url);
    // Reklama tugmasi bosilganda: sanab, asl havolaga yo'naltirish
    const rm = /^\/r\/(\d+)\/(\d+)\/([a-f0-9]+)$/.exec(pathname);
    if (rm) {
      const target = bc.click(Number(rm[1]), Number(rm[2]), rm[3]);
      if (!target) {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
        return res.end('Topilmadi');
      }
      res.writeHead(302, { Location: target, 'Cache-Control': 'no-store' });
      return res.end();
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') {
      res.writeHead(405);
      return res.end();
    }
    if (pathname.startsWith('/img/')) {
      const name = path.basename(pathname);
      if (!/^[\w.-]+$/.test(name)) {
        res.writeHead(404);
        return res.end();
      }
      return serveFile(res, db.imgDir, name, 'public, max-age=604800');
    }
    if (pathname === '/') pathname = '/index.html';
    serveFile(res, cfg.publicDir, pathname.replace(/^\/+/, ''), pathname.startsWith('/signs/') ? 'public, max-age=86400' : 'no-cache');
  });

  function start() {
    return new Promise((resolve) => {
      server.listen(cfg.port, '0.0.0.0', () => {
        console.log(`[http] server ${cfg.port}-portda ishlamoqda`);
        resolve();
      });
    });
  }

  return { start, server };
}

module.exports = createHttp;
