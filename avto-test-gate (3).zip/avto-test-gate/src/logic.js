'use strict';
// Asosiy biznes-mantiq: foydalanuvchi, test, referal, obuna, pul yechish

const TZ_OFFSET_MS = 5 * 3600 * 1000; // Toshkent vaqti (UTC+5)

function fmt(n) {
  return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' so’m';
}

function esc(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function dayKey(ts = Date.now()) {
  return new Date(ts + TZ_OFFSET_MS).toISOString().slice(0, 10);
}

// Mukofot oralig'ini matn ko'rinishida: "10 000 – 30 000 so’m" yoki bitta summa
function rewardLabel(s) {
  const min = Math.min(s.rewardMin, s.rewardMax);
  const max = Math.max(s.rewardMin, s.rewardMax);
  return min === max ? fmt(max) : fmt(min).replace(/ so’m$/, '') + ' – ' + fmt(max);
}

// min va max orasidan tasodifiy summa. Ikkalasi 1000 (yoki 100) ga karrali bo'lsa, natija ham shunday bo'ladi.
function randomReward(s) {
  const min = Math.max(0, Math.floor(Math.min(s.rewardMin, s.rewardMax)) || 0);
  const max = Math.max(0, Math.floor(Math.max(s.rewardMin, s.rewardMax)) || 0);
  if (max <= min) return min;
  const step = min % 1000 === 0 && max % 1000 === 0 ? 1000 : min % 100 === 0 && max % 100 === 0 ? 100 : 1;
  const steps = Math.floor((max - min) / step);
  return min + Math.floor(Math.random() * (steps + 1)) * step;
}

class AppError extends Error {}

function createLogic({ db, tg, cfg, rt }) {
  const d = () => db.data;

  function displayName(tu) {
    const name = [tu.first_name, tu.last_name].filter(Boolean).join(' ').trim();
    return (name || tu.username || 'Foydalanuvchi').slice(0, 64);
  }

  function addTx(u, type, amount, note) {
    u.tx.unshift({ type, amount, note: note || '', at: Date.now() });
    if (u.tx.length > 40) u.tx.length = 40;
  }

  function refLink(u) {
    return rt.botUsername ? `https://t.me/${rt.botUsername}?start=ref_${u.id}` : '';
  }

  function shareUrl(u) {
    const s = d().settings;
    const text = `AvtoTest — test ishlang va pul ishlang! Har bir to’g’ri javob uchun ${rewardLabel(s)}.`;
    return `https://t.me/share/url?url=${encodeURIComponent(refLink(u))}&text=${encodeURIComponent(text)}`;
  }

  // Foydalanuvchini topish yoki yaratish. Yangi bo'lsa va referal bo'lsa — taklif qilganga bonus.
  function ensureUser(tu, refId) {
    const id = Number(tu.id);
    let u = d().users[id];
    let isNew = false;
    if (!u) {
      isNew = true;
      u = {
        id,
        name: displayName(tu),
        username: tu.username || '',
        balance: 0,
        correct: 0,
        wrong: 0,
        answered: {},
        days: {},
        invited: [],
        refBy: null,
        opened: {},
        tx: [],
        joinedAt: Date.now(),
      };
      d().users[id] = u;
      const rid = Number(refId);
      const referrer = rid && rid !== id ? d().users[rid] : null;
      if (referrer) {
        const bonus = Math.max(0, Number(d().settings.refBonus) || 0);
        u.refBy = rid;
        referrer.balance += bonus;
        referrer.invited.unshift({ id, name: u.name, at: Date.now(), bonus });
        addTx(referrer, 'ref', bonus, u.name);
        tg.send(
          referrer.id,
          `🎉 Do’stingiz <b>${esc(u.name)}</b> sizning havolangiz orqali botga qo’shildi!\n\n` +
            `💰 Sizga <b>${fmt(bonus)}</b> berildi.\n` +
            `💳 Jami hisobingiz: <b>${fmt(referrer.balance)}</b>\n` +
            `👥 Taklif qilgan do’stlaringiz: <b>${referrer.invited.length} ta</b>`
        );
      }
    } else {
      if (u.blocked) u.blocked = false; // qaytib kelgan foydalanuvchi
      const name = displayName(tu);
      if (name !== u.name || (tu.username || '') !== u.username) {
        u.name = name;
        u.username = tu.username || '';
      }
    }
    // Statistika: onlayn (oxirgi faollik) va kunlik faol foydalanuvchilar soni
    u.seen = Date.now();
    const today = dayKey();
    if (u.lastDay !== today) {
      u.lastDay = today;
      dailyAdd(today, 'active');
    }
    db.save();
    return { user: u, isNew };
  }

  // Kunlik hisoblagichlar: { "2026-11-16": { active, zay } } — oxirgi 60 kun saqlanadi
  function dailyAdd(day, field) {
    if (!d().daily) d().daily = {};
    const all = d().daily;
    if (!all[day]) {
      all[day] = {};
      const keys = Object.keys(all);
      if (keys.length > 60) {
        const limit = dayKey(Date.now() - 60 * 86400000);
        for (const k of keys) if (k < limit) delete all[k];
      }
    }
    all[day][field] = (all[day][field] || 0) + 1;
  }

  // Admin statistikasi (100 ming foydalanuvchini aylanib chiqadi, shuning uchun 30 sekund keshlanadi)
  let statsCache = null;
  function adminStats() {
    if (statsCache && Date.now() - statsCache.at < 30000) return statsCache.data;
    const now = Date.now();
    const DAYS = 14;
    const keys = [];
    for (let i = DAYS - 1; i >= 0; i--) keys.push(dayKey(now - i * 86400000));
    const idx = new Map(keys.map((k, i) => [k, i]));
    const fresh = new Array(DAYS).fill(0);
    const answered = new Array(DAYS).fill(0);
    const daily = d().daily || {};
    const totals = { users: 0, blocked: 0, online: 0, last24h: 0 };
    for (const u of Object.values(d().users)) {
      totals.users += 1;
      if (u.blocked) totals.blocked += 1;
      if (u.seen && now - u.seen < 5 * 60000) totals.online += 1;
      if (u.seen && now - u.seen < 86400000) totals.last24h += 1;
      const j = idx.get(dayKey(u.joinedAt || 0));
      if (j !== undefined) fresh[j] += 1;
      for (let i = 0; i < DAYS; i++) if (u.days && u.days[keys[i]]) answered[i] += 1;
    }
    const days = keys.map((k, i) => {
      const c = daily[k] || {};
      return {
        day: k,
        fresh: fresh[i],
        // Hisoblagich yoqilgan kundan boshlab — botga kirganlar; undan oldingi kunlar uchun — test ishlaganlar
        active: Math.max(c.active || 0, answered[i]),
        tested: answered[i],
        zay: c.zay || 0,
      };
    });
    const channels = d().channels
      .filter((c) => c.type === 'request')
      .map((c) => ({ title: c.title, total: Object.keys(d().joinReq[c.chatId] || {}).length }));
    const t = days[DAYS - 1];
    const data = {
      totals: Object.assign(totals, {
        newToday: t.fresh,
        activeToday: t.active,
        testedToday: t.tested,
        zayToday: t.zay,
        zayTotal: Object.values(d().joinReq).reduce((s, m) => s + Object.keys(m).length, 0),
      }),
      days,
      channels,
      at: now,
    };
    statsCache = { at: now, data };
    return data;
  }

  // ---------- Test ----------
  function publicQuestion(q) {
    return { id: q.id, text: q.text, options: q.options, image: q.image || '' };
  }

  // Foydalanuvchining savol tartibi: barcha savollar (rasmli va yozuvli) aralash tartibda.
  // Tartib foydalanuvchiga bir marta tuziladi va saqlanadi; savollar o'zgarsa, qayta tuziladi.
  function shuffle(arr) {
    const a = arr.slice();
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }
  function orderFor(u, qs) {
    const ids = qs.map((q) => q.id);
    const stale = !Array.isArray(u.order) || u.order.length !== ids.length || ids.some((id) => !u.order.includes(id));
    if (stale) {
      u.order = shuffle(qs.map((q) => q.id));
      db.save();
    }
    const byId = new Map(qs.map((q) => [q.id, q]));
    return u.order.map((id) => byId.get(id)).filter(Boolean);
  }

  function nextQuestion(u) {
    const qs = d().questions;
    const total = qs.length;
    if (!Array.isArray(u.retry)) u.retry = [];
    let done = 0;
    let next = null;
    const open = new Map();
    for (const q of orderFor(u, qs)) {
      if (u.answered[q.id] === 1) done += 1;
      else {
        open.set(q.id, q);
        // avval hali ko'rilmagan savollar beriladi
        if (!next && !u.retry.includes(q.id)) next = q;
      }
    }
    // keyin xato javob berilganlari qayta beriladi (eng avval xato qilingani birinchi)
    if (!next) {
      for (const id of u.retry) {
        if (open.has(id)) {
          next = open.get(id);
          break;
        }
      }
    }
    if (!next) return { done: true, total, answered: done };
    return { done: false, total, num: done + 1, retry: u.retry.includes(next.id), question: publicQuestion(next) };
  }

  function answer(u, qid, option) {
    const q = d().questions.find((x) => x.id === Number(qid));
    if (!q) throw new AppError('Savol topilmadi');
    if (u.answered[q.id] === 1) throw new AppError('Bu savolga javob berilgan');
    if (!Array.isArray(u.retry)) u.retry = [];
    const opt = Number(option);
    if (!Number.isInteger(opt) || opt < 0 || opt >= q.options.length) throw new AppError('Javob noto’g’ri yuborildi');
    const correct = opt === q.correct;
    let reward = 0;
    // Xato javob berilgan savol navbat oxiriga o'tadi va to'g'ri topilguncha qayta beriladi
    u.retry = u.retry.filter((id) => id !== q.id);
    if (correct) {
      u.answered[q.id] = 1;
      reward = randomReward(d().settings);
      u.balance += reward;
      u.correct += 1;
      const k = dayKey();
      u.days[k] = (u.days[k] || 0) + 1;
      // 40 kundan eski kunlik hisobni tozalash
      const keys = Object.keys(u.days);
      if (keys.length > 45) {
        const limit = dayKey(Date.now() - 40 * 86400000);
        for (const key of keys) if (key < limit) delete u.days[key];
      }
      addTx(u, 'answer', reward, '');
    } else {
      delete u.answered[q.id];
      u.retry.push(q.id);
      u.wrong += 1;
    }
    db.save();
    // To'g'ri javob faqat topilganda ochiladi — aks holda qayta berilganda tayyor javob bo'lib qoladi
    const res = { correct, reward, balance: u.balance };
    if (correct) res.correctIndex = q.correct;
    return res;
  }

  // ---------- Reyting ----------
  function points(u, keys) {
    if (!keys) return u.correct;
    let s = 0;
    for (const k of keys) s += u.days[k] || 0;
    return s;
  }

  // Reyting 100 ming foydalanuvchini saralaydi — har so'rovda emas, daqiqada bir marta hisoblanadi
  const RATING_TTL = 60000;
  const ratingCache = {};
  function ratingData(period) {
    const c = ratingCache[period];
    if (c && Date.now() - c.at < RATING_TTL) return c;
    let keys = null;
    if (period === 'w' || period === 'm') {
      keys = [];
      const n = period === 'w' ? 7 : 30;
      for (let i = 0; i < n; i++) keys.push(dayKey(Date.now() - i * 86400000));
    }
    const list = Object.values(d().users)
      .map((u) => ({ id: u.id, name: u.name, pts: points(u, keys) }))
      .sort((a, b) => b.pts - a.pts || a.id - b.id);
    const pos = new Map();
    list.forEach((x, i) => pos.set(x.id, i));
    const top = list.filter((x) => x.pts > 0).slice(0, 50);
    return (ratingCache[period] = { at: Date.now(), pos, pts: list.map((x) => x.pts), top, total: list.length });
  }

  function rating(period, meId) {
    const c = ratingData(period);
    const me = Number(meId);
    const idx = c.pos.has(me) ? c.pos.get(me) : -1;
    const top = c.top.map((x, i) => ({ rank: i + 1, name: x.name, pts: x.pts, me: x.id === me }));
    // Yangi qo'shilgan foydalanuvchi keshda bo'lmasa, vaqtincha ro'yxat oxirida turadi
    return { top, me: { rank: idx >= 0 ? idx + 1 : c.total + 1, pts: idx >= 0 ? c.pts[idx] : 0 }, total: c.total };
  }

  function rankOf(u) {
    return rating('a', u.id).me.rank;
  }

  // ---------- Majburiy obuna ----------
  async function checkSubs(u) {
    return Promise.all(
      d().channels.map(async (ch) => {
        let ok = false;
        if (ch.type === 'link') {
          ok = !!u.opened[ch.id]; // oddiy havola: tekshirib bo'lmaydi, ochilgani hisoblanadi
        } else if (ch.type === 'request' && d().joinReq[ch.chatId] && d().joinReq[ch.chatId][u.id]) {
          ok = true; // zayavka yuborgan
        } else {
          try {
            const m = await tg.call('getChatMember', { chat_id: ch.chatId, user_id: u.id }, 8000);
            ok = ['creator', 'administrator', 'member'].includes(m.status) || (m.status === 'restricted' && m.is_member === true);
          } catch (e) {
            // Foydalanuvchi topilmasa — obuna emas. Boshqa xato (bot kanaldan chiqarilgan va h.k.)
            // bo'lsa foydalanuvchini bloklab qo'ymaslik uchun o'tkazib yuboriladi.
            ok = !/user not found|PARTICIPANT|USER_ID_INVALID|member not found/i.test(e.message);
            if (ok) console.warn(`[obuna] ${ch.title} (${ch.chatId}) tekshirilmadi: ${e.message}`);
          }
        }
        return { id: ch.id, type: ch.type, title: ch.title, url: ch.url, ok };
      })
    );
  }

  // 3 ta to'g'ri javobdan keyin: yangi (hali tasdiqlanmagan) kanal bo'lsa va
  // foydalanuvchi obuna bo'lmagan bo'lsa, majburiy obuna oynasi chiqadi.
  // Obuna bo'lgan kanal u.gateOk da saqlanadi — keyin shu kanal qayta tekshirilmaydi.
  async function gateRequired(u) {
    const chans = d().channels;
    if (!chans.length) return false;
    if (!u.gateOk) u.gateOk = {};
    if (chans.every((c) => u.gateOk[c.id])) return false;
    const subs = await checkSubs(u);
    let all = true;
    for (const c of subs) {
      if (c.ok) u.gateOk[c.id] = 1;
      else all = false;
    }
    return !all;
  }

  // ---------- Pul yechish ----------
  function hasPending(u) {
    return d().withdrawals.some((w) => w.userId === u.id && w.status === 'pending');
  }

  async function withdrawStatus(u) {
    const s = d().settings;
    // Majburiy obuna endi bot chatida (/start) tekshiriladi, mini appda so'ralmaydi
    const channels = [];
    const subscribed = true;
    const refCount = u.invited.length;
    const refsOk = refCount >= s.refRequired;
    const balanceOk = u.balance >= s.minWithdraw && u.balance > 0;
    const pending = hasPending(u);
    return {
      channels,
      subscribed,
      refCount,
      refRequired: s.refRequired,
      refBonus: s.refBonus,
      refsOk,
      balance: u.balance,
      minWithdraw: s.minWithdraw,
      balanceOk,
      pending,
      canWithdraw: subscribed && refsOk && balanceOk && !pending,
    };
  }

  async function createWithdrawal(u, amountRaw, cardRaw) {
    const st = await withdrawStatus(u);
    if (!st.subscribed) throw new AppError('Avval kanallarga obuna bo’ling');
    if (!st.refsOk) throw new AppError(`Pul yechish uchun ${st.refRequired} ta do’st taklif qilishingiz kerak`);
    if (st.pending) throw new AppError('Oldingi so’rovingiz hali ko’rib chiqilmoqda');
    const amount = Math.floor(Number(amountRaw));
    const card = String(cardRaw || '').replace(/\D/g, '');
    if (!Number.isFinite(amount) || amount <= 0) throw new AppError('Summani to’g’ri kiriting');
    if (amount < st.minWithdraw) throw new AppError(`Minimal yechish summasi: ${fmt(st.minWithdraw)}`);
    if (amount > u.balance) throw new AppError('Hisobingizda mablag’ yetarli emas');
    if (card.length !== 16) throw new AppError('Karta raqami 16 ta raqamdan iborat bo’lishi kerak');

    u.balance -= amount;
    addTx(u, 'withdraw', -amount, 'Ko’rib chiqilmoqda');
    const w = { id: db.nextId('w'), userId: u.id, name: u.name, username: u.username, amount, card, status: 'pending', at: Date.now(), doneAt: 0 };
    d().withdrawals.unshift(w);
    db.save();

    const cardPretty = card.replace(/(\d{4})(?=\d)/g, '$1 ');
    for (const adminId of cfg.adminIds) {
      tg.send(
        adminId,
        `💸 <b>Yangi pul yechish so’rovi #${w.id}</b>\n\n` +
          `👤 ${esc(u.name)}${u.username ? ' (@' + esc(u.username) + ')' : ''}\n` +
          `🆔 <code>${u.id}</code>\n` +
          `💰 Summa: <b>${fmt(amount)}</b>\n` +
          `💳 Karta: <code>${cardPretty}</code>\n` +
          `👥 Taklif qilganlari: ${u.invited.length} ta`,
        {
          reply_markup: {
            inline_keyboard: [
              [
                { text: '✅ To’landi', callback_data: `w:pay:${w.id}` },
                { text: '❌ Rad etish', callback_data: `w:rej:${w.id}` },
              ],
            ],
          },
        }
      );
    }
    return { withdrawal: w, balance: u.balance };
  }

  function processWithdrawal(id, action) {
    const w = d().withdrawals.find((x) => x.id === Number(id));
    if (!w) throw new AppError('So’rov topilmadi');
    if (w.status !== 'pending') throw new AppError('Bu so’rov allaqachon ko’rib chiqilgan');
    const u = d().users[w.userId];
    if (action === 'pay') {
      w.status = 'paid';
      w.doneAt = Date.now();
      if (u) {
        const t = u.tx.find((x) => x.type === 'withdraw' && x.note === 'Ko’rib chiqilmoqda' && x.amount === -w.amount);
        if (t) t.note = 'To’landi';
        tg.send(u.id, `✅ <b>${fmt(w.amount)}</b> kartangizga o’tkazildi.\n💳 Karta: <code>•••• ${w.card.slice(-4)}</code>`);
      }
    } else if (action === 'reject') {
      w.status = 'rejected';
      w.doneAt = Date.now();
      if (u) {
        u.balance += w.amount;
        const t = u.tx.find((x) => x.type === 'withdraw' && x.note === 'Ko’rib chiqilmoqda' && x.amount === -w.amount);
        if (t) t.note = 'Rad etildi';
        addTx(u, 'refund', w.amount, 'So’rov rad etildi');
        tg.send(u.id, `❌ Pul yechish so’rovingiz rad etildi.\n💰 <b>${fmt(w.amount)}</b> hisobingizga qaytarildi.`);
      }
    } else {
      throw new AppError('Noma’lum amal');
    }
    db.save();
    return w;
  }

  return {
    fmt,
    esc,
    rewardLabel,
    AppError,
    ensureUser,
    refLink,
    shareUrl,
    nextQuestion,
    answer,
    rating,
    rankOf,
    dailyAdd,
    adminStats,
    checkSubs,
    gateRequired,
    withdrawStatus,
    createWithdrawal,
    processWithdrawal,
    hasPending,
  };
}

module.exports = createLogic;
module.exports.AppError = AppError;
module.exports.fmt = fmt;
module.exports.esc = esc;
module.exports.dayKey = dayKey;
