'use strict';
const path = require('path');

const env = process.env;

const adminIds = String(env.ADMIN_ID || env.ADMIN_IDS || '')
  .split(/[\s,;]+/)
  .filter(Boolean)
  .map(Number)
  .filter((n) => Number.isFinite(n) && n > 0);

let webappUrl = (env.WEBAPP_URL || '').trim();
if (!webappUrl && env.RAILWAY_PUBLIC_DOMAIN) webappUrl = 'https://' + env.RAILWAY_PUBLIC_DOMAIN.trim();
webappUrl = webappUrl.replace(/\/+$/, '');

module.exports = {
  botToken: (env.BOT_TOKEN || '').trim(),
  adminIds,
  webappUrl,
  port: Number(env.PORT) || 3000,
  // Railway Volume ulanganda RAILWAY_VOLUME_MOUNT_PATH avtomatik beriladi
  dataDir: path.resolve(env.DATA_DIR || env.RAILWAY_VOLUME_MOUNT_PATH || path.join(__dirname, '..', 'data')),
  publicDir: path.join(__dirname, '..', 'public'),
  telegramApi: (env.TELEGRAM_API || 'https://api.telegram.org').replace(/\/+$/, ''),
  // Faqat lokal sinov uchun: Telegram'siz brauzerda ochish (?dev=USER_ID)
  devMode: env.DEV_MODE === '1',
  isAdmin(id) {
    return adminIds.includes(Number(id));
  },
};
