'use strict';
// Reklama (ommaviy xabar) yuborish: istalgan turdagi xabar + inline tugma + statistika.
// Xabar copyMessage orqali nusxalanadi, shuning uchun matn, rasm, video, ovozli xabar,
// fayl, dumaloq video, stiker — hammasi asl ko'rinishida boradi.
const crypto = require('crypto');
const { AppError } = require('./logic');

const SEND_GAP_MS = 45; // sekundiga ~22 ta xabar (Telegram chegarasi ~30)
const BATCH = 25; // bir vaqtda yuboriladigan xabarlar
const BATCH_MS = 1050; // har bir guruh kamida shuncha davom etadi
const KEEP = 300; // tarixda saqlanadigan reklamalar soni

const KINDS = [
  ['text', 'Matn'],
  ['photo', 'Rasm'],
  ['video', 'Video'],
  ['voice', 'Ovozli xabar'],
  ['audio', 'Audio'],
  ['video_note', 'Dumaloq video'],
  ['animation', 'GIF'],
  ['document', 'Fayl'],
  ['sticker', 'Stiker'],
  ['poll', 'So’rovnoma'],
  ['location', 'Joylashuv'],
  ['contact', 'Kontakt'],
];

function createBroadcast({ db, tg, cfg, rt, logic }) {
  const { esc } = logic;
  const d = () => db.data;
  const running = new Set();
  const albumWarned = new Set();
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function find(id) {
    return d().broadcasts.find((b) => b.id === Number(id));
  }

  function sig(bid, uid) {
    return crypto.createHmac('sha256', cfg.botToken).update(`ad:${bid}:${uid}`).digest('hex').slice(0, 12);
  }

  function normUrl(raw) {
    let u = String(raw || '').trim();
    if (!u) return '';
    if (u.startsWith('@')) u = 'https://t.me/' + u.slice(1);
    else if (/^t\.me\//i.test(u)) u = 'https://' + u;
    if (!/^https?:\/\/[^\s]+$/i.test(u)) throw new AppError('Tugma havolasi noto’g’ri. Masalan: https://t.me/kanal');
    return u;
  }

  // Tugma: har bir foydalanuvchiga o'z havolasi beriladi, shunda bosganlar sanaladi
  function markup(b, uid, tracked) {
    if (!b.btnText || !b.btnUrl) return undefined;
    const url = tracked && cfg.webappUrl ? `${cfg.webappUrl}/r/${b.id}/${uid}/${sig(b.id, uid)}` : b.btnUrl;
    return { inline_keyboard: [[{ text: b.btnText, url }]] };
  }

  function statsText(b) {
    const lines = [
      `👥 Jami: <b>${b.total}</b>`,
      `✅ Yetib bordi: <b>${b.delivered}</b>`,
      `🚫 Botni bloklagan: <b>${b.blocked}</b>`,
      `⚠️ Xato: <b>${b.failed}</b>`,
    ];
    if (b.btnUrl) lines.push(`👆 Tugmani bosgan: <b>${b.clicks}</b>`);
    return lines.join('\n');
  }

  // 1-qadam: admin paneldan (yoki /reklama buyrug'i bilan) boshlash
  async function begin(adminId, btnTextRaw, btnUrlRaw) {
    const btnText = String(btnTextRaw || '').trim().slice(0, 64);
    const btnUrl = normUrl(btnUrlRaw);
    if (!!btnText !== !!btnUrl) throw new AppError('Tugma uchun matn ham, havola ham kiritilishi kerak (yoki ikkalasini bo’sh qoldiring)');
    d().adState[adminId] = { btnText, btnUrl, at: Date.now() };
    db.save();
    await tg.send(
      adminId,
      `📣 <b>Yangi reklama</b>\n\n` +
        `Endi reklama xabarini shu chatga yuboring. Istalgan turda bo’lishi mumkin: matn, rasm, video, ovozli xabar, dumaloq video, fayl, GIF.\n\n` +
        (btnText ? `🔘 Tugma: <b>${esc(btnText)}</b>\n🔗 ${esc(btnUrl)}\n\n` : `🔘 Tugmasiz yuboriladi.\n\n`) +
        `Bekor qilish: /bekor`
    );
  }

  // 2-qadam: admin xabar yubordi → qoralama + ko'rib chiqish
  // true qaytarsa, xabar shu yerda qayta ishlangan
  async function onAdminMessage(msg) {
    const adminId = msg.from.id;
    const st = d().adState[adminId];
    const text = (msg.text || '').trim();
    if (/^\/(bekor|cancel)\b/i.test(text)) {
      if (!st) return false;
      delete d().adState[adminId];
      db.save();
      await tg.send(adminId, 'Reklama bekor qilindi.');
      return true;
    }
    if (!st) {
      // albomning qolgan qismlari salomlashuv xabarini chaqirmasin
      return !!(msg.media_group_id && albumWarned.has(msg.media_group_id));
    }
    if (text.startsWith('/')) return false; // boshqa buyruqlar odatdagidek ishlaydi
    if (msg.media_group_id) {
      if (!albumWarned.has(msg.media_group_id)) {
        albumWarned.add(msg.media_group_id);
        await tg.send(adminId, 'Albom (bir nechta rasm/video birga) yuborib bo’lmaydi. Iltimos, bitta xabar yuboring.');
      }
      return true;
    }
    const kind = (KINDS.find(([k]) => msg[k] !== undefined) || ['other', 'Xabar'])[1];
    const b = {
      id: db.nextId('b'),
      by: adminId,
      fromChatId: msg.chat.id,
      messageId: msg.message_id,
      kind,
      preview: String(msg.text || msg.caption || '').slice(0, 140),
      btnText: st.btnText,
      btnUrl: st.btnUrl,
      status: 'draft', // draft → sending → done | stopped | cancelled
      total: 0,
      delivered: 0,
      blocked: 0,
      failed: 0,
      clicks: 0,
      clicked: {},
      lastId: 0,
      createdAt: Date.now(),
      startedAt: 0,
      finishedAt: 0,
    };
    d().broadcasts.unshift(b);
    if (d().broadcasts.length > KEEP) d().broadcasts.length = KEEP;
    delete d().adState[adminId];
    db.save();

    try {
      await tg.call('copyMessage', { chat_id: adminId, from_chat_id: b.fromChatId, message_id: b.messageId, reply_markup: markup(b, adminId, false) });
    } catch (e) {
      b.status = 'cancelled';
      db.save();
      await tg.send(adminId, `Bu xabarni yuborib bo’lmaydi: ${esc(e.message)}\nBoshqa xabar bilan qayta urinib ko’ring.`);
      return true;
    }
    const users = Object.keys(d().users).length;
    await tg.send(adminId, `☝️ Reklama #${b.id} shu ko’rinishda <b>${users}</b> ta foydalanuvchiga yuboriladi.\n\nTasdiqlaysizmi?`, {
      reply_markup: {
        inline_keyboard: [
          [
            { text: '✅ Yuborish', callback_data: `b:send:${b.id}` },
            { text: '❌ Bekor qilish', callback_data: `b:cancel:${b.id}` },
          ],
        ],
      },
    });
    return true;
  }

  async function sendOne(b, uid) {
    for (let attempt = 0; attempt < 4; attempt++) {
      try {
        await tg.call('copyMessage', { chat_id: uid, from_chat_id: b.fromChatId, message_id: b.messageId, reply_markup: markup(b, uid, true) }, 15000);
        return 'ok';
      } catch (e) {
        if (e.code === 429) {
          await sleep(((e.retryAfter || 3) + 1) * 1000);
          continue;
        }
        if (e.code === 403 || /blocked|deactivated/i.test(e.message)) return 'blocked';
        if (e.name === 'AbortError' && attempt < 2) continue;
        return 'failed';
      }
    }
    return 'failed';
  }

  // 3-qadam: yuborish (server qayta ishga tushsa, qolgan joyidan davom etadi)
  async function run(id) {
    const b = find(id);
    if (!b || b.status !== 'sending' || running.has(b.id)) return;
    running.add(b.id);
    try {
      const ids = Object.keys(d().users)
        .map(Number)
        .filter((x) => x > b.lastId)
        .sort((x, y) => x - y);
      // Parallel yuborish: sekundiga BATCH tagacha xabar (Telegram chegarasi ~30/s).
      // Botni bloklaganlarga qayta yuborilmaydi — ular darhol "blokladi" deb sanaladi.
      let lastSave = Date.now();
      for (let i = 0; i < ids.length && b.status === 'sending'; ) {
        const t0 = Date.now();
        const batch = [];
        while (i < ids.length && batch.length < BATCH) {
          const uid = ids[i++];
          const u = d().users[uid];
          if (!u) continue;
          if (u.blocked) {
            b.blocked += 1;
            continue;
          }
          batch.push(uid);
        }
        const results = await Promise.all(batch.map((uid) => sendOne(b, uid)));
        results.forEach((r, k) => {
          const u = d().users[batch[k]];
          if (r === 'ok') {
            b.delivered += 1;
            if (u) u.blocked = false;
          } else if (r === 'blocked') {
            b.blocked += 1;
            if (u) u.blocked = true;
          } else {
            b.failed += 1;
          }
        });
        b.lastId = ids[i - 1];
        // Katta bazani har xabarda yozish yuborishni sekinlashtiradi — 5 sekundda bir marta saqlanadi
        if (Date.now() - lastSave > 5000) {
          db.save();
          lastSave = Date.now();
        }
        const wait = BATCH_MS - (Date.now() - t0);
        if (batch.length && wait > 0) await sleep(wait);
      }
      if (b.status === 'sending') b.status = 'done';
      b.finishedAt = Date.now();
      db.save();
      await tg.send(b.by, `📣 <b>Reklama #${b.id} ${b.status === 'done' ? 'yuborib bo’lindi' : 'to’xtatildi'}</b>\n\n${statsText(b)}`);
    } finally {
      running.delete(b.id);
    }
  }

  function start(id) {
    const b = find(id);
    if (!b) throw new AppError('Reklama topilmadi');
    if (b.status !== 'draft') throw new AppError('Bu reklama allaqachon yuborilgan yoki bekor qilingan');
    b.status = 'sending';
    b.startedAt = Date.now();
    b.total = Object.keys(d().users).length;
    db.save();
    run(b.id).catch((e) => console.error('[reklama] xato:', e));
    return b;
  }

  function cancel(id) {
    const b = find(id);
    if (!b) throw new AppError('Reklama topilmadi');
    if (b.status === 'draft') b.status = 'cancelled';
    else if (b.status === 'sending') b.status = 'stopped';
    else throw new AppError('Bu reklama allaqachon yakunlangan');
    if (!b.finishedAt) b.finishedAt = Date.now();
    db.save();
    return b;
  }

  // Bot chatidagi tasdiqlash tugmalari
  function onCallback(action, id) {
    if (action === 'send') {
      const b = start(id);
      return `📤 Reklama #${b.id} yuborilmoqda (${b.total} ta foydalanuvchi). Tugagach hisobot keladi.`;
    }
    const b = cancel(id);
    return b.status === 'stopped' ? `⏹ Reklama #${b.id} to’xtatildi.` : `❌ Reklama #${b.id} bekor qilindi.`;
  }

  // Tugma bosilganda: hisoblab, asl havolaga yo'naltirish
  function click(bid, uid, s) {
    const b = find(bid);
    if (!b || !b.btnUrl) return null;
    const a = Buffer.from(String(s || ''));
    const e = Buffer.from(sig(b.id, Number(uid)));
    if (a.length !== e.length || !crypto.timingSafeEqual(a, e)) return null;
    if (!b.clicked[uid]) {
      b.clicked[uid] = 1;
      b.clicks += 1;
      db.save();
    }
    return b.btnUrl;
  }

  function resume() {
    for (const b of d().broadcasts) {
      if (b.status === 'sending') run(b.id).catch((e) => console.error('[reklama] xato:', e));
    }
  }

  function list() {
    return d().broadcasts.slice(0, 100).map((b) => ({
      id: b.id,
      kind: b.kind,
      preview: b.preview,
      btnText: b.btnText,
      btnUrl: b.btnUrl,
      status: b.status,
      total: b.total,
      delivered: b.delivered,
      blocked: b.blocked,
      failed: b.failed,
      clicks: b.clicks,
      sent: b.delivered + b.blocked + b.failed,
      createdAt: b.createdAt,
      finishedAt: b.finishedAt,
    }));
  }

  return { begin, onAdminMessage, onCallback, start, cancel, click, resume, list };
}

module.exports = createBroadcast;
