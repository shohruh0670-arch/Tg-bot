(function () {
  'use strict';

  var tg = window.Telegram && window.Telegram.WebApp ? window.Telegram.WebApp : null;
  var params = new URLSearchParams(location.search);
  var devUser = params.get('dev') || '';
  var $view = document.getElementById('view');
  var $tabs = document.getElementById('tabs');
  var $overlay = document.getElementById('overlay');
  var $toast = document.getElementById('toast');

  var S = {
    me: null,
    settings: null,
    isAdmin: false,
    refLink: '',
    shareUrl: '',
    tab: 'test',
    test: null, // { done, total, num, question }
    locked: false,
    picked: null, // { index, correctIndex }
    period: 'w',
    admin: null,
    adminTab: 'dash',
    dash: null,
    chType: 'public',
    editQ: null,
    overlayLocked: false,
  };

  // ---------- Yordamchilar ----------
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmt(n) {
    return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ') + ' so’m';
  }
  function num(n) {
    return String(Math.round(Number(n) || 0)).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
  function ini(name) {
    var p = String(name || '?').trim().split(/\s+/);
    return ((p[0] || '?').charAt(0) + (p[1] ? p[1].charAt(0) : '')).toUpperCase();
  }
  function pad(n) {
    return n < 10 ? '0' + n : '' + n;
  }
  function fmtDate(ts) {
    var d = new Date(ts);
    return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + '.' + d.getFullYear() + ', ' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }
  function toast(msg) {
    $toast.textContent = msg;
    $toast.classList.add('show');
    clearTimeout(toast.t);
    toast.t = setTimeout(function () {
      $toast.classList.remove('show');
    }, 2600);
  }
  function haptic(type) {
    try {
      if (tg && tg.HapticFeedback) tg.HapticFeedback.notificationOccurred(type);
    } catch (e) {}
  }
  function openLink(url) {
    if (!url) return;
    try {
      if (tg && /^https?:\/\/t\.me\//i.test(url) && tg.openTelegramLink) return tg.openTelegramLink(url);
      if (tg && tg.openLink) return tg.openLink(url);
    } catch (e) {}
    window.open(url, '_blank');
  }
  function confirmBox(msg, cb) {
    try {
      if (tg && tg.showConfirm && tg.isVersionAtLeast && tg.isVersionAtLeast('6.2')) return tg.showConfirm(msg, cb);
    } catch (e) {}
    cb(window.confirm(msg));
  }
  function copyText(text) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand('copy');
      } catch (e) {}
      document.body.removeChild(ta);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).catch(fallback);
    else fallback();
    toast('Havola nusxalandi');
  }

  function api(path, body) {
    var headers = { 'Content-Type': 'application/json', 'X-Init-Data': tg ? tg.initData || '' : '' };
    if (devUser) headers['X-Dev-User'] = devUser;
    return fetch('/api/' + path, {
      method: body ? 'POST' : 'GET',
      headers: headers,
      body: body ? JSON.stringify(body) : undefined,
    })
      .then(function (r) {
        return r.json().catch(function () {
          return { ok: false, error: 'Server javobi noto’g’ri' };
        });
      })
      .then(function (j) {
        if (!j.ok) throw new Error(j.error || 'Xatolik yuz berdi');
        return j;
      });
  }
  function fail(e) {
    toast(e && e.message === 'Failed to fetch' ? 'Internet aloqasini tekshiring' : (e && e.message) || 'Xatolik yuz berdi');
  }

  // ---------- Ikonkalar ----------
  function svg(d, extra) {
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (extra || 2) + '" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + d + '</svg>';
  }
  var I = {
    test: svg('<path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>'),
    cup: svg('<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 0 1-10 0V4z"/><path d="M17 5h3v2a3 3 0 0 1-3 3M7 5H4v2a3 3 0 0 0 3 3"/>'),
    users: svg('<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>'),
    wallet: svg('<rect x="2" y="6" width="20" height="14" rx="2"/><path d="M2 10h20M16 15h2"/>'),
    check: svg('<path d="M5 12l5 5L20 7"/>', 2.6),
    x: svg('<path d="M18 6L6 18M6 6l12 12"/>', 2.4),
    shield: svg('<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="M9 12l2 2 4-4"/>', 1.8),
    share: svg('<path d="M4 12v8a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-8M16 6l-4-4-4 4M12 2v13"/>'),
    copy: svg('<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>'),
    gear: svg('<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h.1a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v.1a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>', 1.6),
    edit: svg('<path d="M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>'),
    trash: svg('<path d="M3 6h18M8 6V4h8v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>'),
    plus: svg('<path d="M12 5v14M5 12h14"/>', 2.4),
    back: svg('<path d="M15 18l-6-6 6-6"/>', 2.4),
    clock: svg('<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>'),
  };

  // ---------- Overlay ----------
  function openOverlay(html, mode, locked) {
    $overlay.className = mode || 'bottom';
    $overlay.innerHTML = html;
    $overlay.hidden = false;
    S.overlayLocked = !!locked;
  }
  function closeOverlay() {
    $overlay.hidden = true;
    $overlay.innerHTML = '';
    S.overlayLocked = false;
  }
  $overlay.addEventListener('click', function (e) {
    if (e.target === $overlay && !S.overlayLocked) closeOverlay();
  });

  // ---------- Tablar ----------
  var TABS = [
    ['test', 'Test', I.test],
    ['rating', 'Reyting', I.cup],
    ['refs', 'Takliflarim', I.users],
    ['account', 'Hisobim', I.wallet],
  ];
  function renderTabs() {
    $tabs.hidden = false;
    $tabs.innerHTML = TABS.map(function (t) {
      return '<button type="button" data-act="tab" data-tab="' + t[0] + '" class="' + (S.tab === t[0] ? 'on' : '') + '">' + t[2] + t[1] + '</button>';
    }).join('');
  }
  var VIEWS = {};
  function show(tab) {
    S.tab = tab;
    renderTabs();
    $view.scrollTop = 0;
    VIEWS[tab]();
  }
  function loading() {
    $view.innerHTML = '<div class="loading"><div class="spinner"></div></div>';
  }

  // ---------- TEST ----------
  function drawTest() {
    if (S.tab !== 'test') return;
    var t = S.test;
    if (!t) return loading();
    if (t.done) {
      $view.innerHTML =
        '<div class="spacer"></div><div class="col center" style="align-items:center">' +
        '<div class="avatar" style="width:72px;height:72px;background:var(--green-soft);color:var(--green-dark)">' + I.check + '</div>' +
        '<h1 class="title">' + (t.total ? 'Barcha savollar tugadi' : 'Hozircha savollar yo’q') + '</h1>' +
        '<p class="muted">' + (t.total ? 'Yangi savollar tez orada qo’shiladi. Unga qadar do’stlaringizni taklif qilib pul ishlang: har bir do’st uchun <b>' + esc(fmt(S.settings.refBonus)) + '</b>.' : 'Savollar tez orada qo’shiladi.') + '</p>' +
        '</div><div class="spacer"></div>' +
        '<button type="button" class="btn green" data-act="share">' + I.share + 'Do’stlarni taklif qilish</button>';
      return;
    }
    var q = t.question;
    var p = S.picked;
    var pct = t.total ? Math.round(((t.num - 1) / t.total) * 100) : 0;
    var html =
      '<div class="col" style="gap:12px">' +
      '<div class="row between"><b style="font-size:15px">Savol ' + t.num + ' / ' + t.total + '</b>' +
      '<span class="chip green">+' + esc(S.settings.rewardLabel) + '</span></div>' +
      '<div class="bar"><i style="width:' + pct + '%"></i></div></div>';
    if (q.image) {
      html += '<div class="qimg"><img src="' + esc(q.image) + '" alt="Savol rasmi"></div>' +
        '<h2 class="qtext">' + esc(q.text) + '</h2><div class="spacer"></div>';
    } else {
      // rasmsiz savol: matn bo'sh joyning o'rtasida turadi
      html += '<div class="qmid"><h2 class="qtext">' + esc(q.text) + '</h2></div>';
    }
    html += '<div class="answers">';
    if (p && !p.correct) {
      html += '<div class="wrongnote">' + I.x + 'Noto’g’ri javob. Bu savol keyinroq qayta beriladi.</div>';
    }
    q.options.forEach(function (o, i) {
      var cls = 'ans';
      if (p) {
        if (p.correct && i === p.index) cls += ' ok';
        else if (!p.correct && i === p.index) cls += ' bad';
      }
      html += '<button type="button" class="' + cls + '" data-act="pick" data-i="' + i + '"><b>' + 'ABC'.charAt(i) + '</b><span>' + esc(o) + '</span></button>';
    });
    html += '</div>';
    $view.innerHTML = html;
  }
  VIEWS.test = function () {
    if (S.test) return drawTest();
    loading();
    api('question')
      .then(function (r) {
        S.test = r;
        drawTest();
      })
      .catch(fail);
  };
  function pick(i) {
    if (S.locked || !S.test || S.test.done) return;
    S.locked = true;
    var qid = S.test.question.id;
    api('answer', { qid: qid, option: i })
      .then(function (r) {
        S.picked = { index: i, correct: r.correct };
        drawTest();
        var goNext = function () {
          S.test = r.next;
          S.picked = null;
          S.locked = false;
          if (!$overlay.hidden && $overlay.querySelector('.popup')) closeOverlay();
          drawTest();
          if (r.subPrompt) subPromptFlow();
        };
        if (r.correct) {
          haptic('success');
          S.me.balance = r.balance;
          S.me.correct += 1;
          setTimeout(function () {
            openOverlay(
              '<div class="popup" role="dialog" aria-label="To’g’ri javob">' +
                '<div class="head"><div class="tick">' + I.check + '</div>To’g’ri javob!</div>' +
                '<div class="body"><div class="col center" style="gap:4px"><span class="small muted">Sizga berildi</span>' +
                '<span class="sum">+' + esc(fmt(r.reward)) + '</span></div>' +
                '<div class="total"><span>Jami hisobingiz</span><b>' + esc(fmt(r.balance)) + '</b></div>' +
                '<div class="col" style="gap:8px"><div class="autobar"><i></i></div>' +
                '<span class="xs muted center">Keyingi savolga avtomatik o’tilmoqda…</span></div></div></div>',
              'mid',
              true
            );
          }, 350);
          setTimeout(goNext, 2900);
        } else {
          haptic('error');
          setTimeout(goNext, 1500);
        }
      })
      .catch(function (e) {
        S.locked = false;
        S.test = null;
        S.picked = null;
        fail(e);
        if (S.tab === 'test') VIEWS.test();
      });
  }

  // ---------- REYTING ----------
  VIEWS.rating = function () {
    var head =
      '<h1 class="title">Reyting</h1><div class="seg">' +
      [['w', 'Haftalik'], ['m', 'Oylik'], ['a', 'Umumiy']]
        .map(function (p) {
          return '<button type="button" data-act="period" data-p="' + p[0] + '" class="' + (S.period === p[0] ? 'on' : '') + '">' + p[1] + '</button>';
        })
        .join('') +
      '</div>';
    $view.innerHTML = head + '<div class="loading"><div class="spinner"></div></div>';
    var period = S.period;
    api('rating?period=' + period)
      .then(function (r) {
        if (S.tab !== 'rating' || S.period !== period) return;
        var html = head;
        var top = r.top;
        if (!top.length) {
          html += '<div class="empty">Hozircha reyting bo’sh.<br>Birinchi bo’lib test ishlang!</div>';
        } else {
          var rest = top;
          if (top.length >= 3) {
            var pod = function (x, cls) {
              return '<div class="' + cls + '"><div class="av">' + esc(ini(x.name)) + '</div><span class="nm">' + esc(x.name) + '</span>' +
                '<div class="st"><b>' + x.rank + '</b>' + num(x.pts) + ' ball</div></div>';
            };
            html += '<div class="podium">' + pod(top[1], 'p2') + pod(top[0], 'p1') + pod(top[2], 'p3') + '</div>';
            rest = top.slice(3);
          }
          if (rest.length) {
            html += '<div class="list">' + rest.map(function (x) {
              return '<div><span class="rk">' + x.rank + '</span><div class="avatar sm">' + esc(ini(x.name)) + '</div>' +
                '<span class="grow ellip" style="font-weight:600">' + esc(x.name) + (x.me ? ' (siz)' : '') + '</span><b>' + num(x.pts) + ' ball</b></div>';
            }).join('') + '</div>';
          }
        }
        html += '<div class="spacer"></div><div class="merow"><span class="rk" style="color:var(--green-dark)">' + (r.me.pts > 0 ? r.me.rank : '–') + '</span>' +
          '<div class="avatar sm">' + esc(ini(S.me.name)) + '</div><span class="grow">Siz</span><span style="color:var(--green-dark)">' + num(r.me.pts) + ' ball</span></div>';
        $view.innerHTML = html;
      })
      .catch(fail);
  };

  // ---------- TAKLIFLARIM ----------
  VIEWS.refs = function () {
    loading();
    api('refs')
      .then(function (r) {
        if (S.tab !== 'refs') return;
        S.refLink = r.link;
        S.shareUrl = r.shareUrl;
        S.me.refCount = r.count;
        var pct = r.required > 0 ? Math.min(100, Math.round((r.count / r.required) * 100)) : 100;
        var html =
          '<h1 class="title">Takliflarim</h1>' +
          '<div class="hero"><div class="row between"><div class="col" style="gap:2px"><span class="small" style="color:#14532d;font-weight:600">Har bir do’st uchun</span>' +
          '<span class="big">+' + esc(fmt(r.bonus)) + '</span></div>' +
          '<div class="avatar" style="background:#fff;color:var(--green-dark)">' + I.users + '</div></div>' +
          '<p class="small" style="color:#14532d">Do’stingiz havolangiz orqali botga kirsa, mukofot darhol hisobingizga tushadi va bot sizga xabar yuboradi.</p></div>' +
          '<div class="stats" style="grid-template-columns:repeat(2,minmax(0,1fr))">' +
          '<div class="stat"><b>' + r.count + ' ta</b><span>Taklif qilingan do’stlar</span></div>' +
          '<div class="stat"><b>' + esc(fmt(r.earned)) + '</b><span>Takliflardan daromad</span></div></div>';
        if (r.required > 0) {
          html += '<div class="card col" style="gap:10px"><div class="row between"><span class="small" style="font-weight:600">Pul yechish uchun</span>' +
            '<b class="small">' + Math.min(r.count, r.required) + ' / ' + r.required + ' do’st</b></div><div class="bar"><i style="width:' + pct + '%"></i></div>' +
            '<span class="xs muted">' + (r.count >= r.required ? 'Shart bajarildi — pul yechishingiz mumkin.' : 'Yana ' + (r.required - r.count) + ' ta do’st taklif qilsangiz, pul yechish ochiladi.') + '</span></div>';
        }
        html += '<div class="col" style="gap:8px"><span class="small" style="font-weight:600">Sizning havolangiz</span>' +
          '<div class="linkbox"><span>' + esc(r.link || 'Havola tayyorlanmoqda…') + '</span>' +
          '<button type="button" class="btn sm ghost" data-act="copy">' + I.copy + 'Nusxa</button></div></div>' +
          '<button type="button" class="btn green" data-act="share">' + I.share + 'Do’stlarni taklif qilish</button>' +
          '<h2 class="h2">Taklif qilganlarim</h2>';
        if (!r.list.length) {
          html += '<div class="empty">Hali hech kimni taklif qilmadingiz.</div>';
        } else {
          html += '<div class="list">' + r.list.map(function (x) {
            return '<div><div class="avatar sm">' + esc(ini(x.name)) + '</div><div class="grow"><div class="ellip" style="font-weight:600">' + esc(x.name) + '</div>' +
              '<div class="xs muted">' + fmtDate(x.at) + '</div></div><span class="plus">+' + esc(fmt(x.bonus)) + '</span></div>';
          }).join('') + '</div>';
        }
        $view.innerHTML = html;
      })
      .catch(fail);
  };

  // ---------- HISOBIM ----------
  function txRow(t) {
    var minus = t.amount < 0;
    var title = { answer: 'To’g’ri javob', ref: 'Do’st taklifi', withdraw: 'Pul yechish', refund: 'Pul qaytarildi' }[t.type] || 'Amal';
    var sub = fmtDate(t.at) + (t.note ? ' · ' + t.note : '');
    return '<div><div class="txicon' + (minus ? ' minus' : '') + '">' + (minus ? '−' : '+') + '</div><div class="grow"><div style="font-weight:600">' + title + '</div>' +
      '<div class="xs muted ellip">' + esc(sub) + '</div></div><span class="' + (minus ? 'minus-t' : 'plus') + '">' + (minus ? '−' : '+') + esc(fmt(Math.abs(t.amount))) + '</span></div>';
  }
  function drawAccount() {
    if (S.tab !== 'account') return;
    var u = S.me;
    var html =
      '<div class="row"><div class="avatar">' + esc(ini(u.name)) + '</div><div class="grow"><div class="ellip" style="font-size:16px;font-weight:700">' + esc(u.name) + '</div>' +
      '<div class="small muted">ID: ' + u.id + '</div></div>' +
      (S.isAdmin ? '<button type="button" class="btn sm ghost" data-act="admin">' + I.gear + 'Admin</button>' : '') + '</div>' +
      '<div class="balance"><div class="col" style="gap:6px"><span class="lbl">Joriy balans</span><span class="amt">' + esc(fmt(u.balance)) + '</span></div>' +
      '<div class="two"><button type="button" class="btn" data-act="withdraw">Pul yechish</button>' +
      '<button type="button" class="btn line" data-act="share">Do’st taklif qilish</button></div>' +
      '<span class="xs" style="color:#dcfce7">Minimal yechish summasi: ' + esc(fmt(S.settings.minWithdraw)) + '</span></div>' +
      '<div class="stats"><div class="stat"><b>' + num(u.correct) + '</b><span>To’g’ri javob</span></div>' +
      '<div class="stat"><b>' + num(u.refCount) + '</b><span>Do’stlar</span></div>' +
      '<div class="stat"><b>' + (u.correct > 0 ? '#' + u.rank : '–') + '</b><span>Reytingda</span></div></div>' +
      '<h2 class="h2">Tranzaksiyalar</h2>';
    html += u.tx && u.tx.length ? '<div class="list">' + u.tx.map(txRow).join('') + '</div>' : '<div class="empty">Hozircha tranzaksiyalar yo’q.</div>';
    $view.innerHTML = html;
  }
  function loadMe() {
    return api('me').then(function (r) {
      S.me = r.user;
      S.settings = r.settings;
      S.isAdmin = r.isAdmin;
      S.refLink = r.refLink;
      S.shareUrl = r.shareUrl;
      return r;
    });
  }
  VIEWS.account = function () {
    if (S.me) drawAccount();
    loadMe().then(drawAccount).catch(fail);
  };

  // ---------- PUL YECHISH ----------
  function sheet(inner) {
    openOverlay('<div class="sheet" role="dialog"><div class="grip"></div>' + inner + '</div>', 'bottom');
  }
  // 3-chi to'g'ri javobdan keyin bir marta: obuna bo'lmagan bo'lsa kanallar ro'yxati chiqadi
  function subPromptRows(st) {
    return st.channels.map(function (c) {
      var right = c.ok
        ? '<span class="okmark">' + I.check + 'Bajarildi</span>'
        : '<button type="button" class="btn sm" data-act="opench" data-id="' + c.id + '" data-type="' + c.type + '" data-url="' + esc(c.url) + '">' +
          (c.type === 'request' ? 'So’rov yuborish' : c.type === 'link' ? 'Ochish' : 'Obuna bo’lish') + '</button>';
      return '<div class="chrow"><div class="avatar">' + esc(ini(c.title)) + '</div><div class="grow"><div class="ellip" style="font-weight:600">' + esc(c.title) + '</div>' +
        '<div class="xs muted">' + (c.type === 'request' ? 'Yopiq kanal · so’rov yuboring' : c.type === 'link' ? 'Havola' : 'Kanal') + '</div></div>' + right + '</div>';
    }).join('');
  }
  function subPromptFlow() {
    api('withdraw/check', {})
      .then(function (st) {
        if (st.subscribed) return;
        // Majburiy: yopib bo'lmaydi (locked), faqat obuna bo'lgandan keyin yopiladi
        openOverlay(
          '<div class="sheet" role="dialog"><div class="grip"></div>' +
            '<div class="icon">' + I.shield + '</div><h2>AvtoTest kanallariga obuna bo’ling</h2>' +
            '<p class="lead">Testni davom ettirish uchun quyidagi kanallarga obuna bo’ling.</p>' +
            '<div class="col" style="gap:10px">' + subPromptRows(st) + '</div>' +
            '<button type="button" class="btn dark" data-act="subcheck">Tekshirish</button></div>',
          'bottom',
          true
        );
      })
      .catch(function () {});
  }

  function withdrawFlow(recheck) {
    api('withdraw/check', {})
      .then(function (st) {
        S.me.balance = st.balance;
        S.me.refCount = st.refCount;
        if (!st.subscribed) {
          if (recheck) toast('Hali barcha kanallarga obuna bo’lmadingiz');
          var rows = st.channels.map(function (c) {
            var right = c.ok
              ? '<span class="okmark">' + I.check + 'Bajarildi</span>'
              : '<button type="button" class="btn sm" data-act="opench" data-id="' + c.id + '" data-type="' + c.type + '" data-url="' + esc(c.url) + '">' +
                (c.type === 'request' ? 'So’rov yuborish' : c.type === 'link' ? 'Ochish' : 'Obuna bo’lish') + '</button>';
            return '<div class="chrow"><div class="avatar">' + esc(ini(c.title)) + '</div><div class="grow"><div class="ellip" style="font-weight:600">' + esc(c.title) + '</div>' +
              '<div class="xs muted">' + (c.type === 'request' ? 'Yopiq kanal · so’rov yuboring' : c.type === 'link' ? 'Havola' : 'Kanal') + '</div></div>' + right + '</div>';
          }).join('');
          return sheet(
            '<div class="icon">' + I.shield + '</div><h2>Majburiy obuna</h2>' +
              '<p class="lead">Pulni yechib olish uchun quyidagi kanallarga obuna bo’ling</p>' +
              '<div class="col" style="gap:10px">' + rows + '</div>' +
              '<button type="button" class="btn dark" data-act="recheck">Tekshirish</button>'
          );
        }
        if (!st.refsOk) {
          var left = st.refRequired - st.refCount;
          var pct = Math.min(100, Math.round((st.refCount / st.refRequired) * 100));
          return sheet(
            '<div class="icon green">' + I.users + '</div><h2>Do’stlaringizni taklif qiling</h2>' +
              '<p class="lead">Pulni yechib olish uchun <b>' + st.refRequired + ' ta</b> do’stingizni AvtoTest botga taklif qiling. Har bir do’st uchun sizga <b>' + esc(fmt(st.refBonus)) + '</b> beriladi.</p>' +
              '<div class="card col" style="gap:10px"><div class="row between"><span class="small" style="font-weight:600">Taklif qilingan</span><b class="small">' + st.refCount + ' / ' + st.refRequired + '</b></div>' +
              '<div class="bar"><i style="width:' + pct + '%"></i></div><span class="xs muted">Yana ' + left + ' ta do’st taklif qilishingiz kerak.</span></div>' +
              '<button type="button" class="btn green" data-act="share">' + I.share + 'Do’stlarni taklif qilish</button>' +
              '<button type="button" class="btn ghost" data-act="gorefs">Takliflarimni ko’rish</button>'
          );
        }
        if (st.pending) {
          return sheet('<div class="icon">' + I.clock + '</div><h2>So’rovingiz ko’rib chiqilmoqda</h2>' +
            '<p class="lead">Oldingi pul yechish so’rovingiz hali ko’rib chiqilmoqda. Natija haqida bot sizga xabar yuboradi.</p>' +
            '<button type="button" class="btn ghost" data-act="close">Yopish</button>');
        }
        if (!st.balanceOk) {
          return sheet('<div class="icon">' + I.wallet + '</div><h2>Mablag’ yetarli emas</h2>' +
            '<p class="lead">Minimal yechish summasi <b>' + esc(fmt(st.minWithdraw)) + '</b>. Hisobingizda <b>' + esc(fmt(st.balance)) + '</b> bor.</p>' +
            '<button type="button" class="btn green" data-act="gotest">Test ishlashni davom ettirish</button>');
        }
        sheet(
          '<div class="icon green">' + I.wallet + '</div><h2>Pul yechish</h2>' +
            '<p class="lead">Hisobingizda: <b>' + esc(fmt(st.balance)) + '</b></p>' +
            '<label class="f">Summa (so’m)<input class="in" id="w-amount" type="number" inputmode="numeric" min="' + st.minWithdraw + '" max="' + st.balance + '" value="' + st.balance + '"></label>' +
            '<label class="f">Karta raqami (Uzcard / Humo)<input class="in" id="w-card" type="text" inputmode="numeric" maxlength="19" placeholder="8600 0000 0000 0000" autocomplete="off"></label>' +
            '<span class="hint">Minimal summa: ' + esc(fmt(st.minWithdraw)) + '. So’rov admin tomonidan ko’rib chiqiladi.</span>' +
            '<button type="button" class="btn green" data-act="sendw">So’rov yuborish</button>'
        );
      })
      .catch(fail);
  }
  function sendWithdraw(btn) {
    var amount = Number(document.getElementById('w-amount').value);
    var card = document.getElementById('w-card').value.replace(/\D/g, '');
    if (card.length !== 16) return toast('Karta raqamini to’liq kiriting (16 ta raqam)');
    btn.disabled = true;
    api('withdraw', { amount: amount, card: card })
      .then(function (r) {
        S.me.balance = r.balance;
        haptic('success');
        sheet('<div class="icon green">' + I.check + '</div><h2>So’rov yuborildi</h2>' +
          '<p class="lead"><b>' + esc(fmt(amount)) + '</b> yechish so’rovingiz qabul qilindi. Natija haqida bot sizga xabar yuboradi.</p>' +
          '<button type="button" class="btn ghost" data-act="close">Yopish</button>');
        if (S.tab === 'account') VIEWS.account();
      })
      .catch(function (e) {
        btn.disabled = false;
        fail(e);
      });
  }

  // ---------- ADMIN ----------
  // ---------- Admin: statistika oynasi ----------
  var MONTHS = ['yanvar', 'fevral', 'mart', 'aprel', 'may', 'iyun', 'iyul', 'avgust', 'sentabr', 'oktabr', 'noyabr', 'dekabr'];
  function dayLabel(key, short) {
    var p = key.split('-');
    return short ? p[2] + '.' + p[1] : Number(p[2]) + '-' + MONTHS[Number(p[1]) - 1];
  }
  function loadDash(manual) {
    api('admin/stats')
      .then(function (r) {
        S.dash = r;
        if (S.admin && S.tab === 'admin' && S.adminTab === 'dash') drawAdmin();
        if (manual) toast('Yangilandi');
      })
      .catch(fail);
  }
  function dashChart(days) {
    var W = 340, H = 170, L = 30, B = 20, T = 8;
    var series = [['fresh', '#16a34a'], ['active', '#1d4ed8'], ['zay', '#dc2626']];
    var max = 1;
    days.forEach(function (d) { series.forEach(function (s) { if (d[s[0]] > max) max = d[s[0]]; }); });
    var ih = H - B - T, gw = (W - L) / days.length, bw = Math.max(2, Math.min(7, (gw - 4) / 3));
    var out = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="So’nggi 14 kun">';
    for (var g = 0; g <= 2; g++) {
      var y = T + ih - (ih * g) / 2;
      out += '<line x1="' + L + '" x2="' + W + '" y1="' + y + '" y2="' + y + '" stroke="#e2e8f0"/>' +
        '<text x="' + (L - 4) + '" y="' + (y + 3) + '" text-anchor="end" font-size="9" fill="#64748b">' + num((max * g) / 2) + '</text>';
    }
    days.forEach(function (d, i) {
      var x0 = L + i * gw + (gw - bw * 3 - 2) / 2;
      series.forEach(function (s, j) {
        var h = (ih * d[s[0]]) / max;
        out += '<rect x="' + (x0 + j * (bw + 1)).toFixed(1) + '" y="' + (T + ih - h).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + h.toFixed(1) + '" rx="1.5" fill="' + s[1] + '"/>';
      });
      if (i % 2 === 1 || i === days.length - 1) {
        out += '<text x="' + (L + i * gw + gw / 2) + '" y="' + (H - 5) + '" text-anchor="middle" font-size="9" fill="#64748b">' + dayLabel(d.day, true) + '</text>';
      }
    });
    return out + '</svg>';
  }
  function dashHtml() {
    var r = S.dash;
    if (!r) return '<div class="loading"><div class="spinner"></div></div>';
    var t = r.totals;
    var card = function (cls, value, label, sub) {
      return '<div class="dcard ' + cls + '"><b>' + num(value) + '</b><span>' + label + '</span>' + (sub ? '<i>' + sub + '</i>' : '') + '</div>';
    };
    var html =
      '<div class="dgrid">' +
      card('g', t.online, 'Hozir onlayn', 'oxirgi 5 daqiqa') +
      card('b', t.activeToday, 'Bugun faol', 'test ishladi: ' + num(t.testedToday)) +
      card('g', t.newToday, 'Bugun qo’shildi', 'jami: ' + num(t.users)) +
      card('r', t.zayToday, 'Bugun zayavka', 'jami: ' + num(t.zayTotal)) +
      card('b', t.last24h, '24 soatda kirgan', '') +
      card('r', t.blocked, 'Botni bloklagan', t.users ? Math.round((t.blocked / t.users) * 100) + '% foydalanuvchi' : '') +
      '</div>' +
      '<div class="card col" style="gap:10px"><div class="row between"><b>So’nggi 14 kun</b>' +
      '<span class="dlegend"><i class="g"></i>Yangi<i class="b"></i>Faol<i class="r"></i>Zayavka</span></div>' + dashChart(r.days) + '</div>';
    if (r.channels.length) {
      html += '<div class="card col" style="gap:8px"><b>Zayavka kanallari</b>' + r.channels.map(function (c) {
        return '<div class="row between"><span class="ellip grow">' + esc(c.title) + '</span><span class="chip red">' + num(c.total) + ' ta</span></div>';
      }).join('') + '</div>';
    }
    html += '<div class="card col" style="gap:0"><b style="margin-bottom:6px">Kunlar bo’yicha</b>' +
      '<div class="drow dhead"><span>Kun</span><span>Qo’shildi</span><span>Faol</span><span>Zayavka</span></div>' +
      r.days.slice().reverse().map(function (d, i) {
        return '<div class="drow"><span>' + dayLabel(d.day) + (i === 0 ? ' · bugun' : '') + '</span><span class="tg">+' + num(d.fresh) + '</span><span class="tb">' + num(d.active) + '</span><span class="tr">' + num(d.zay) + '</span></div>';
      }).join('') + '</div>' +
      '<p class="xs muted">«Faol» va «Zayavka»ning kunlik soni shu yangilanish o’rnatilgan kundan boshlab to’liq yig’iladi. Undan oldingi kunlarda «Faol» — o’sha kuni test ishlaganlar.</p>' +
      '<button type="button" class="btn ghost" data-act="dashreload">Yangilash</button>';
    return html;
  }

  function drawAdmin() {
    if (S.tab !== 'admin') return;
    var a = S.admin;
    var st = a.stats;
    var html =
      '<div class="row"><button type="button" class="iconbtn" data-act="tab" data-tab="account" aria-label="Orqaga">' + I.back + '</button><h1 class="title">Admin panel</h1></div>' +
      '<div class="seg scroll">' +
      [['dash', 'Statistika'], ['stats', 'Sozlamalar'], ['channels', 'Kanallar'], ['questions', 'Savollar'], ['pays', 'To’lovlar' + (st.pending ? ' (' + st.pending + ')' : '')], ['ads', 'Reklama']]
        .map(function (t) {
          return '<button type="button" data-act="atab" data-t="' + t[0] + '" class="' + (S.adminTab === t[0] ? 'on' : '') + '">' + t[1] + '</button>';
        })
        .join('') +
      '</div>';

    if (S.adminTab === 'dash') html += dashHtml();

    if (S.adminTab === 'stats') {
      var s = a.settings;
      html +=
        '<div class="stats"><div class="stat"><b>' + num(st.users) + '</b><span>Foydalanuvchi</span></div>' +
        '<div class="stat"><b>' + num(st.newToday) + '</b><span>24 soatda yangi</span></div>' +
        '<div class="stat"><b>' + num(st.refs) + '</b><span>Jami referal</span></div>' +
        '<div class="stat"><b>' + num(st.totalBalance) + '</b><span>Balanslar (so’m)</span></div>' +
        '<div class="stat"><b>' + num(st.totalPaid) + '</b><span>To’langan (so’m)</span></div>' +
        '<div class="stat"><b>' + num(st.pending) + '</b><span>Kutilmoqda</span></div>' +
        '<div class="stat"><b>' + num(st.blocked) + '</b><span>Botni bloklagan</span></div></div>' +
        '<h2 class="h2">Sozlamalar</h2>' +
        '<label class="f">Referal bonusi — bitta do’st uchun (so’m)<input class="in" id="s-refBonus" type="number" inputmode="numeric" min="0" value="' + s.refBonus + '"></label>' +
        '<label class="f">Referal soni — pul yechish uchun kerakli do’stlar<input class="in" id="s-refRequired" type="number" inputmode="numeric" min="0" value="' + s.refRequired + '"><span class="hint">0 kiritilsa, do’st taklif qilish sharti o’chiriladi.</span></label>' +
        '<div class="col" style="gap:6px"><span class="small muted" style="font-weight:600">To’g’ri javob mukofoti (so’m)</span>' +
        '<div class="row"><label class="f grow">Minimal<input class="in" id="s-rewardMin" type="number" inputmode="numeric" min="0" value="' + s.rewardMin + '"></label>' +
        '<label class="f grow">Maksimal<input class="in" id="s-rewardMax" type="number" inputmode="numeric" min="0" value="' + s.rewardMax + '"></label></div>' +
        '<span class="hint">Har bir to’g’ri javobga shu oraliqdan tasodifiy summa beriladi. Bir xil summa bo’lsin desangiz, ikkalasiga bir xil son yozing.</span></div>' +
        '<label class="f">Minimal yechish summasi (so’m)<input class="in" id="s-minWithdraw" type="number" inputmode="numeric" min="0" value="' + s.minWithdraw + '"></label>' +
        '<label class="f">/start xabari (botga kirganda chiqadi)<textarea class="in" id="s-startText" rows="6">' + esc(s.startText || '') + '</textarea>' +
        '<span class="hint">O’zgaruvchilar: {name} — ism, {reward} — to’g’ri javob mukofoti, {refBonus} — do’st bonusi, {refRequired} — kerakli do’stlar, {balance} — balans. HTML: <b>qalin</b>. Bo’sh qoldirilsa, standart matn chiqadi.</span></label>' +
        '<button type="button" class="btn green" data-act="savesettings">Saqlash</button>';
      if (!a.webappUrl) html += '<div class="wrongnote">WEBAPP_URL sozlanmagan — Railway’da domen yarating.</div>';
    }

    if (S.adminTab === 'channels') {
      html += '<p class="small muted">Bu kanallar botda /start bosilganda majburiy obuna sifatida chiqadi.</p>';
      if (!a.channels.length) html += '<div class="empty">Kanal qo’shilmagan — majburiy obuna o’chiq.</div>';
      else {
        html += '<div class="col" style="gap:10px">' + a.channels.map(function (c) {
          var tname = { public: 'Ommaviy kanal', request: 'Zayavka kanal', link: 'Oddiy havola' }[c.type];
          return '<div class="chrow"><div class="grow"><div class="ellip" style="font-weight:600">' + esc(c.title) + '</div>' +
            '<div class="xs muted ellip">' + esc(c.url) + '</div><span class="tag">' + tname + '</span></div>' +
            '<button type="button" class="iconbtn red" data-act="delch" data-id="' + c.id + '" aria-label="O’chirish">' + I.trash + '</button></div>';
        }).join('') + '</div>';
      }
      html += '<button type="button" class="btn" data-act="addch">' + I.plus + 'Kanal yoki havola qo’shish</button>';
    }

    if (S.adminTab === 'questions') {
      html += '<button type="button" class="btn" data-act="addq">' + I.plus + 'Savol qo’shish</button>';
      if (!a.questions.length) html += '<div class="empty">Savollar yo’q.</div>';
      else {
        html += '<div class="col" style="gap:10px">' + a.questions.map(function (q, i) {
          return '<div class="chrow">' + (q.image ? '<img class="qthumb" src="' + esc(q.image) + '" alt="">' : '<div class="qthumb"></div>') +
            '<div class="grow"><div class="small" style="font-weight:600">' + (i + 1) + '. ' + esc(q.text) + '</div>' +
            '<div class="xs" style="color:var(--green-dark)">' + 'ABC'.charAt(q.correct) + ') ' + esc(q.options[q.correct]) + '</div></div>' +
            '<button type="button" class="iconbtn" data-act="editq" data-id="' + q.id + '" aria-label="Tahrirlash">' + I.edit + '</button>' +
            '<button type="button" class="iconbtn red" data-act="delq" data-id="' + q.id + '" aria-label="O’chirish">' + I.trash + '</button></div>';
        }).join('') + '</div>';
      }
    }

    if (S.adminTab === 'pays') {
      if (!a.withdrawals.length) html += '<div class="empty">Pul yechish so’rovlari yo’q.</div>';
      else {
        html += '<div class="col" style="gap:10px">' + a.withdrawals.map(function (w) {
          var card = String(w.card).replace(/(\d{4})(?=\d)/g, '$1 ');
          var status = w.status === 'pending' ? '<span class="chip blue">Kutilmoqda</span>' : w.status === 'paid' ? '<span class="chip green">To’landi</span>' : '<span class="chip red">Rad etildi</span>';
          var h = '<div class="card col" style="gap:10px"><div class="row between"><b>#' + w.id + ' · ' + esc(fmt(w.amount)) + '</b>' + status + '</div>' +
            '<div class="small"><div class="ellip">' + esc(w.name) + (w.username ? ' (@' + esc(w.username) + ')' : '') + ' · ID ' + w.userId + '</div>' +
            '<div style="font-weight:600;user-select:all">' + card + '</div><div class="xs muted">' + fmtDate(w.at) + '</div></div>';
          if (w.status === 'pending') {
            h += '<div class="row"><button type="button" class="btn sm green grow" data-act="payw" data-id="' + w.id + '">To’landi</button>' +
              '<button type="button" class="btn sm danger grow" data-act="rejw" data-id="' + w.id + '">Rad etish</button></div>';
          }
          return h + '</div>';
        }).join('') + '</div>';
      }
    }
    if (S.adminTab === 'ads') {
      html += '<p class="small muted">Reklama barcha foydalanuvchilarga bot orqali yuboriladi. Har bir reklama statistikasi shu yerda saqlanadi.</p>' +
        '<div class="row"><button type="button" class="btn grow" data-act="newad">' + I.plus + 'Yangi reklama</button>' +
        '<button type="button" class="btn ghost" style="width:auto" data-act="refreshadmin">Yangilash</button></div>';
      if (!a.broadcasts.length) html += '<div class="empty">Hali reklama yuborilmagan.</div>';
      else {
        html += '<div class="col" style="gap:10px">' + a.broadcasts.map(function (b) {
          var status = {
            draft: '<span class="chip">Tasdiq kutilmoqda</span>',
            sending: '<span class="chip blue">Yuborilmoqda ' + b.sent + ' / ' + b.total + '</span>',
            done: '<span class="chip green">Yuborildi</span>',
            stopped: '<span class="chip red">To’xtatildi</span>',
            cancelled: '<span class="chip red">Bekor qilindi</span>',
          }[b.status] || '';
          var h = '<div class="card col" style="gap:10px"><div class="row between"><b>#' + b.id + ' · ' + esc(b.kind) + '</b>' + status + '</div>' +
            '<div class="small">' + (b.preview ? '<div class="clip2">' + esc(b.preview) + '</div>' : '') +
            (b.btnText ? '<div class="xs muted ellip">Tugma: ' + esc(b.btnText) + ' → ' + esc(b.btnUrl) + '</div>' : '<div class="xs muted">Tugmasiz</div>') +
            '<div class="xs muted">' + fmtDate(b.createdAt) + '</div></div>';
          if (b.status !== 'draft' && b.status !== 'cancelled') {
            h += '<div class="adstats"><div><b>' + num(b.total) + '</b><span>Jami</span></div>' +
              '<div><b style="color:var(--green-dark)">' + num(b.delivered) + '</b><span>Yetib bordi</span></div>' +
              '<div><b style="color:var(--red)">' + num(b.blocked) + '</b><span>Blokladi</span></div>' +
              '<div><b>' + (b.btnUrl ? num(b.clicks) : '–') + '</b><span>Tugmani bosdi</span></div></div>';
            if (b.failed) h += '<div class="xs muted">Yuborilmadi (xato): ' + num(b.failed) + '</div>';
          }
          if (b.status === 'sending') h += '<button type="button" class="btn sm danger" data-act="stopad" data-id="' + b.id + '">To’xtatish</button>';
          return h + '</div>';
        }).join('') + '</div>';
      }
    }
    $view.innerHTML = html;
    // tanlangan bo'lim tugmasi ko'rinib tursin (tugmalar qatori gorizontal suriladi)
    var on = $view.querySelector('.seg.scroll .on');
    var bar = on && on.parentNode;
    if (bar) bar.scrollLeft = Math.max(0, on.offsetLeft - (bar.clientWidth - on.offsetWidth) / 2);
  }
  VIEWS.admin = function () {
    $tabs.hidden = true;
    if (S.admin) drawAdmin();
    else loading();
    if (S.adminTab === 'dash') loadDash();
    api('admin/state')
      .then(function (r) {
        S.admin = r;
        drawAdmin();
      })
      .catch(function (e) {
        fail(e);
        show('account');
      });
  };
  function adminPost(path, body, okMsg) {
    return api('admin/' + path, body).then(function (r) {
      S.admin = r;
      if (!S.locked) {
        S.test = null; // savollar o'zgargan bo'lishi mumkin
        S.picked = null;
      }
      if (okMsg) toast(okMsg);
      closeOverlay();
      drawAdmin();
      return r;
    });
  }
  function channelSheet() {
    var t = S.chType;
    var fields = '';
    if (t === 'public') {
      fields =
        '<label class="f">Kanal username’i<input class="in" id="c-chat" type="text" placeholder="@kanal_nomi" autocomplete="off" autocapitalize="off"></label>' +
        '<label class="f">Nomi (ixtiyoriy)<input class="in" id="c-title" type="text" maxlength="80" placeholder="Bo’sh qolsa kanal nomi olinadi"></label>' +
        '<span class="hint">Obuna haqiqatan tekshiriladi. Buning uchun bot shu kanalda <b>admin</b> bo’lishi shart.</span>';
    } else if (t === 'request') {
      fields =
        '<label class="f">Kanal ID raqami<input class="in" id="c-chat" type="text" inputmode="text" placeholder="-1001234567890" autocomplete="off"></label>' +
        '<label class="f">Zayavka havolasi<input class="in" id="c-url" type="url" placeholder="https://t.me/+AbCdEf..." autocomplete="off" autocapitalize="off"></label>' +
        '<label class="f">Nomi (ixtiyoriy)<input class="in" id="c-title" type="text" maxlength="80" placeholder="Bo’sh qolsa kanal nomi olinadi"></label>' +
        '<span class="hint">Botni kanalga admin qiling — bot sizga kanal ID raqamini yuboradi. Havolani kanal sozlamalarida «Qo’shilish so’rovlari» yoqilgan holda yarating. Foydalanuvchi so’rov yuborgan zahoti shart bajarilgan hisoblanadi.</span>';
    } else {
      fields =
        '<label class="f">Nomi<input class="in" id="c-title" type="text" maxlength="80" placeholder="Masalan: Homiy sahifasi"></label>' +
        '<label class="f">Havola<input class="in" id="c-url" type="url" placeholder="https://..." autocomplete="off" autocapitalize="off"></label>' +
        '<span class="hint">Obuna tekshirilmaydi: foydalanuvchi havolani ochsa, shart bajarilgan hisoblanadi (Instagram, sayt, boshqa bot va h.k.).</span>';
    }
    sheet(
      '<h2>Kanal yoki havola qo’shish</h2><div class="seg">' +
        [['public', 'Ommaviy'], ['request', 'Zayavka'], ['link', 'Oddiy havola']]
          .map(function (x) {
            return '<button type="button" data-act="chtype" data-t="' + x[0] + '" class="' + (t === x[0] ? 'on' : '') + '">' + x[1] + '</button>';
          })
          .join('') +
        '</div>' + fields + '<button type="button" class="btn green" data-act="savech">Qo’shish</button>'
    );
  }
  function adSheet() {
    sheet(
      '<h2>Yangi reklama</h2>' +
        '<p class="lead">Xabarning o’zini keyingi qadamda bot chatida yuborasiz: matn, rasm, video, ovozli xabar, dumaloq video yoki fayl — istalgan turda.</p>' +
        '<label class="f">Tugma matni (ixtiyoriy)<input class="in" id="ad-btn" type="text" maxlength="64" placeholder="Masalan: Kanalga o’tish"></label>' +
        '<label class="f">Tugma havolasi (ixtiyoriy)<input class="in" id="ad-url" type="url" placeholder="https://t.me/kanal" autocomplete="off" autocapitalize="off"></label>' +
        '<span class="hint">Tugma kerak bo’lmasa, ikkala maydonni bo’sh qoldiring. Tugma qo’yilsa, uni nechta odam bosgani sanaladi.</span>' +
        '<button type="button" class="btn green" data-act="startad">Davom etish</button>'
    );
  }
  function val(id) {
    var el = document.getElementById(id);
    return el ? el.value.trim() : '';
  }
  function questionSheet(q) {
    S.editQ = q || null;
    var o = q ? q.options : ['', '', ''];
    var c = q ? q.correct : 0;
    var opts = [0, 1, 2]
      .map(function (i) {
        return '<div class="radio"><input type="radio" name="q-correct" value="' + i + '"' + (c === i ? ' checked' : '') + ' aria-label="' + 'ABC'.charAt(i) + ' to’g’ri javob">' +
          '<input class="in" id="q-o' + i + '" type="text" maxlength="200" placeholder="' + 'ABC'.charAt(i) + ' variant" value="' + esc(o[i]) + '"></div>';
      })
      .join('');
    sheet(
      '<h2>' + (q ? 'Savolni tahrirlash' : 'Yangi savol') + '</h2>' +
        '<label class="f">Savol matni<textarea class="in" id="q-text" maxlength="500" placeholder="Savolni yozing">' + esc(q ? q.text : '') + '</textarea></label>' +
        '<div class="col" style="gap:8px"><span class="small muted" style="font-weight:600">Javoblar (to’g’risini belgilang)</span>' + opts + '</div>' +
        '<label class="f">Rasm (ixtiyoriy, 1.5 MB gacha)<input class="in" id="q-img" type="file" accept="image/png,image/jpeg,image/webp"></label>' +
        (q && q.image ? '<label class="radio small"><input type="checkbox" id="q-rmimg" style="width:20px;height:20px"> Hozirgi rasmni olib tashlash</label>' : '') +
        '<button type="button" class="btn green" data-act="saveq">Saqlash</button>'
    );
  }
  function saveQuestion(btn) {
    var checked = document.querySelector('input[name="q-correct"]:checked');
    var body = {
      id: S.editQ ? S.editQ.id : undefined,
      text: val('q-text'),
      options: [val('q-o0'), val('q-o1'), val('q-o2')],
      correct: checked ? Number(checked.value) : 0,
      removeImage: !!(document.getElementById('q-rmimg') && document.getElementById('q-rmimg').checked),
    };
    if (!body.text) return toast('Savol matnini kiriting');
    if (body.options.some(function (x) { return !x; })) return toast('3 ta javob variantini to’ldiring');
    var file = document.getElementById('q-img').files[0];
    var send = function () {
      btn.disabled = true;
      adminPost('question', body, 'Savol saqlandi').catch(function (e) {
        btn.disabled = false;
        fail(e);
      });
    };
    if (!file) return send();
    if (file.size > 1.5 * 1024 * 1024) return toast('Rasm hajmi 1.5 MB dan oshmasin');
    var fr = new FileReader();
    fr.onload = function () {
      body.imageData = String(fr.result);
      send();
    };
    fr.onerror = function () {
      toast('Rasmni o’qib bo’lmadi');
    };
    fr.readAsDataURL(file);
  }

  // ---------- Hodisalar ----------
  var ACT = {
    tab: function (el) {
      show(el.dataset.tab);
    },
    pick: function (el) {
      pick(Number(el.dataset.i));
    },
    period: function (el) {
      S.period = el.dataset.p;
      VIEWS.rating();
    },
    share: function () {
      if (!S.shareUrl || !S.refLink) return toast('Havola tayyorlanmoqda, birozdan so’ng urinib ko’ring');
      openLink(S.shareUrl);
    },
    copy: function () {
      if (S.refLink) copyText(S.refLink);
    },
    withdraw: function () {
      withdrawFlow(false);
    },
    recheck: function () {
      withdrawFlow(true);
    },
    subcheck: function () {
      api('withdraw/check', {})
        .then(function (st) {
          if (st.subscribed) {
            closeOverlay();
            toast('Rahmat! Obuna tasdiqlandi');
            return;
          }
          toast('Hali barcha kanallarga obuna bo’lmadingiz');
          subPromptFlow();
        })
        .catch(fail);
    },
    opench: function (el) {
      if (el.dataset.type === 'link') api('link-open', { id: Number(el.dataset.id) }).catch(function () {});
      openLink(el.dataset.url);
    },
    sendw: function (el) {
      sendWithdraw(el);
    },
    close: closeOverlay,
    gorefs: function () {
      closeOverlay();
      show('refs');
    },
    gotest: function () {
      closeOverlay();
      show('test');
    },
    admin: function () {
      show('admin');
    },
    atab: function (el) {
      S.adminTab = el.dataset.t;
      drawAdmin();
      if (S.adminTab === 'dash') loadDash();
    },
    dashreload: function () {
      loadDash(true);
    },
    savesettings: function (el) {
      el.disabled = true;
      adminPost('settings', { startText: document.getElementById('s-startText').value, rewardMin: val('s-rewardMin'), rewardMax: val('s-rewardMax'), refBonus: val('s-refBonus'), refRequired: val('s-refRequired'), minWithdraw: val('s-minWithdraw') }, 'Sozlamalar saqlandi')
        .then(function (r) {
          S.settings = { rewardMin: r.settings.rewardMin, rewardMax: r.settings.rewardMax, rewardLabel: r.settings.rewardLabel, refBonus: r.settings.refBonus, refRequired: r.settings.refRequired, minWithdraw: r.settings.minWithdraw };
        })
        .catch(function (e) {
          el.disabled = false;
          fail(e);
        });
    },
    newad: function () {
      adSheet();
    },
    startad: function (el) {
      el.disabled = true;
      api('admin/broadcast/start', { btnText: val('ad-btn'), btnUrl: val('ad-url') })
        .then(function () {
          sheet('<div class="icon green">' + I.check + '</div><h2>Bot chatiga o’ting</h2>' +
            '<p class="lead">Bot sizga xabar yubordi. Endi reklama xabarini bot chatiga yuboring — bot uni ko’rsatib, tasdiqlashingizni so’raydi.</p>' +
            '<button type="button" class="btn green" data-act="gochat">Bot chatiga o’tish</button>');
        })
        .catch(function (e) {
          el.disabled = false;
          fail(e);
        });
    },
    gochat: function () {
      closeOverlay();
      try {
        if (tg && tg.close) tg.close();
      } catch (e) {}
    },
    stopad: function (el) {
      confirmBox('Reklama yuborish to’xtatilsinmi?', function (ok) {
        if (ok) adminPost('broadcast/stop', { id: Number(el.dataset.id) }, 'To’xtatildi').catch(fail);
      });
    },
    refreshadmin: function () {
      api('admin/state').then(function (r) {
        S.admin = r;
        drawAdmin();
      }).catch(fail);
    },
    addch: function () {
      channelSheet();
    },
    chtype: function (el) {
      S.chType = el.dataset.t;
      channelSheet();
    },
    savech: function (el) {
      el.disabled = true;
      adminPost('channel', { type: S.chType, chat: val('c-chat'), url: val('c-url'), title: val('c-title') }, 'Qo’shildi').catch(function (e) {
        el.disabled = false;
        fail(e);
      });
    },
    delch: function (el) {
      confirmBox('Bu kanal majburiy obunadan o’chirilsinmi?', function (ok) {
        if (ok) adminPost('channel/delete', { id: Number(el.dataset.id) }, 'O’chirildi').catch(fail);
      });
    },
    addq: function () {
      questionSheet(null);
    },
    editq: function (el) {
      var q = S.admin.questions.filter(function (x) { return x.id === Number(el.dataset.id); })[0];
      if (q) questionSheet(q);
    },
    saveq: function (el) {
      saveQuestion(el);
    },
    delq: function (el) {
      confirmBox('Savol o’chirilsinmi?', function (ok) {
        if (ok) adminPost('question/delete', { id: Number(el.dataset.id) }, 'O’chirildi').then(function () { S.test = null; }).catch(fail);
      });
    },
    payw: function (el) {
      confirmBox('Pul kartaga o’tkazildimi? So’rov «To’landi» deb belgilanadi.', function (ok) {
        if (ok) adminPost('withdrawal', { id: Number(el.dataset.id), action: 'pay' }, 'To’landi deb belgilandi').catch(fail);
      });
    },
    rejw: function (el) {
      confirmBox('So’rov rad etilsinmi? Pul foydalanuvchi hisobiga qaytariladi.', function (ok) {
        if (ok) adminPost('withdrawal', { id: Number(el.dataset.id), action: 'reject' }, 'Rad etildi').catch(fail);
      });
    },
  };
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-act]') : null;
    if (!el || el.disabled) return;
    var fn = ACT[el.dataset.act];
    if (fn) fn(el);
  });

  // ---------- Ishga tushirish ----------
  function boot() {
    try {
      if (tg) {
        tg.ready();
        tg.expand();
        if (tg.setHeaderColor) tg.setHeaderColor('#ffffff');
        if (tg.setBackgroundColor) tg.setBackgroundColor('#ffffff');
      }
    } catch (e) {}
    loadMe()
      .then(function () {
        show(params.get('admin') === '1' && S.isAdmin ? 'admin' : 'test');
      })
      .catch(function (e) {
        $view.innerHTML =
          '<div class="spacer"></div><div class="col center" style="align-items:center"><div class="avatar" style="width:72px;height:72px">' + I.shield + '</div>' +
          '<h1 class="title">AvtoTest</h1><p class="muted">' + esc((e && e.message) || 'Xatolik') + '</p>' +
          '<button type="button" class="btn" style="max-width:240px" onclick="location.reload()">Qayta urinish</button></div><div class="spacer"></div>';
      });
  }
  boot();
})();
