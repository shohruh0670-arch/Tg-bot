'use strict';
// To'liq sinov: soxta Telegram serveri bilan bot va API'ni boshidan oxirigacha tekshiradi.
// Ishga tushirish: npm test   (internet va haqiqiy token kerak emas)
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const TOKEN = '123456:TEST_TOKEN';
const ADMIN = 1;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let passed = 0;
function ok(cond, name) {
  if (!cond) {
    console.error('  ✗ ' + name);
    throw new Error('Sinov o’tmadi: ' + name);
  }
  passed += 1;
  console.log('  ✓ ' + name);
}

// ---------- Soxta Telegram ----------
const mock = { updates: [], sent: [], members: {}, uid: 1, calls: [] };
function pushUpdate(u) {
  mock.updates.push(Object.assign({ update_id: mock.uid++ }, u));
}
function msg(from, text) {
  pushUpdate({ message: { message_id: mock.uid, from, chat: { id: from.id, type: 'private' }, text } });
}
const mockServer = http.createServer((req, res) => {
  let body = '';
  req.on('data', (c) => (body += c));
  req.on('end', async () => {
    const method = req.url.split('/').pop();
    const p = body ? JSON.parse(body) : {};
    mock.calls.push({ method, p });
    let result = true;
    let error = null;
    if (method === 'getMe') result = { id: 999, is_bot: true, username: 'avtotest_bot' };
    else if (method === 'getUpdates') {
      let list = mock.updates.filter((u) => u.update_id >= (p.offset || 0));
      if (!list.length) {
        await sleep(150);
        list = mock.updates.filter((u) => u.update_id >= (p.offset || 0));
      }
      result = list;
    } else if (method === 'sendMessage') {
      mock.sent.push(p);
      result = { message_id: mock.sent.length, chat: { id: p.chat_id }, text: p.text };
    } else if (method === 'getChat') {
      if (p.chat_id === '@chan') result = { id: -1001, title: 'Ommaviy kanal', username: 'chan', type: 'channel' };
      else if (String(p.chat_id) === '-100200') result = { id: -100200, title: 'Yopiq kanal', type: 'channel' };
      else error = 'Bad Request: chat not found';
    } else if (method === 'getChatMember') {
      const st = (mock.members[p.chat_id] || {})[p.user_id];
      result = { status: st || 'left', user: { id: p.user_id } };
    }
    res.writeHead(error ? 400 : 200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(error ? { ok: false, error_code: 400, description: error } : { ok: true, result }));
  });
});

function initData(user) {
  const p = new URLSearchParams();
  p.set('auth_date', String(Math.floor(Date.now() / 1000)));
  p.set('query_id', 'AAE');
  p.set('user', JSON.stringify(user));
  const check = [...p.entries()].map(([k, v]) => `${k}=${v}`).sort().join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(TOKEN).digest();
  p.set('hash', crypto.createHmac('sha256', secret).update(check).digest('hex'));
  return p.toString();
}

(async () => {
  await new Promise((r) => mockServer.listen(0, '127.0.0.1', r));
  const mockPort = mockServer.address().port;
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'avtotest-'));
  const port = 20000 + Math.floor(Math.random() * 20000);
  const base = `http://127.0.0.1:${port}`;
  let child;

  function startApp() {
    child = spawn(process.execPath, [path.join(__dirname, '..', 'src', 'index.js')], {
      env: Object.assign({}, process.env, {
        BOT_TOKEN: TOKEN,
        ADMIN_ID: String(ADMIN),
        WEBAPP_URL: 'https://example.test',
        DATA_DIR: dataDir,
        PORT: String(port),
        TELEGRAM_API: `http://127.0.0.1:${mockPort}`,
        DEV_MODE: '',
      }),
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    child.stdout.on('data', () => {});
    child.stderr.on('data', (c) => process.stderr.write('[app] ' + c));
  }
  async function waitUp() {
    for (let i = 0; i < 50; i++) {
      try {
        const r = await fetch(base + '/health');
        if (r.ok && mock.calls.some((c) => c.method === 'getUpdates')) return;
      } catch (e) {}
      await sleep(100);
    }
    throw new Error('Server ishga tushmadi');
  }
  async function waitFor(fn, name) {
    for (let i = 0; i < 60; i++) {
      if (fn()) return;
      await sleep(50);
    }
    throw new Error('Kutilgan hodisa bo’lmadi: ' + name);
  }
  const users = {
    admin: { id: ADMIN, first_name: 'Admin' },
    ali: { id: 100, first_name: 'Ali', last_name: 'Valiyev', username: 'ali' },
    vali: { id: 200, first_name: 'Vali' },
  };
  async function api(user, p, body, rawInit) {
    const r = await fetch(base + '/api/' + p, {
      method: body ? 'POST' : 'GET',
      headers: { 'Content-Type': 'application/json', 'X-Init-Data': rawInit !== undefined ? rawInit : initData(user) },
      body: body ? JSON.stringify(body) : undefined,
    });
    return Object.assign(await r.json(), { status: r.status });
  }
  const sentTo = (id) => mock.sent.filter((m) => m.chat_id === id);

  try {
    startApp();
    await waitUp();

    console.log('Bot:');
    ok(mock.calls.some((c) => c.method === 'setChatMenuButton' && c.p.menu_button.web_app.url === 'https://example.test'), 'menyu tugmasi mini app manziliga o’rnatildi');
    msg(users.ali, '/start');
    await waitFor(() => sentTo(100).length === 1, '/start javobi');
    ok(sentTo(100)[0].text.includes('Salom') && sentTo(100)[0].reply_markup.inline_keyboard[0][0].web_app.url === 'https://example.test', '/start: salomlashuv va mini app tugmasi');
    msg(users.vali, '/start ref_100');
    await waitFor(() => sentTo(100).length === 2, 'referal xabari');
    const refMsg = sentTo(100)[1].text;
    ok(refMsg.includes('Vali') && refMsg.includes('qo’shildi') && refMsg.includes('5 000 so’m'), 'taklif qilganga xabar: do’st qo’shildi, 5 000 so’m berildi');
    msg(users.vali, '/start ref_100');
    await waitFor(() => sentTo(200).length === 2, 'ikkinchi /start');
    ok(sentTo(100).length === 2, 'takroriy /start uchun bonus qayta berilmaydi');
    msg({ id: 300, first_name: 'Solo' }, '/start ref_300');
    await waitFor(() => sentTo(300).length === 1, 'o’ziga referal');

    console.log('API:');
    let r = await api(null, 'me', null, 'user=%7B%22id%22%3A100%7D&hash=abc');
    ok(r.status === 401, 'soxta initData rad etiladi (401)');
    r = await api(users.ali, 'me');
    ok(r.ok && r.user.balance === 5000 && r.user.refCount === 1 && r.isAdmin === false, 'Ali: balans 5 000, 1 ta do’st');
    ok(r.refLink === 'https://t.me/avtotest_bot?start=ref_100', 'referal havola to’g’ri');
    r = await api({ id: 300, first_name: 'Solo' }, 'me');
    ok(r.user.balance === 0 && r.user.refCount === 0, 'o’zini o’zi taklif qilish ishlamaydi');

    console.log('Test:');
    r = await api(users.admin, 'admin/settings', { rewardMin: 500, rewardMax: 500, refBonus: 5000, refRequired: 5, minWithdraw: 20000 });
    ok(r.ok && r.settings.rewardMin === 500, 'admin: mukofot 500 qilib qo’yildi');
    r = await api(users.ali, 'question');
    ok(r.ok && !r.done && r.num === 1 && r.total === 10 && r.question.correct === undefined, 'savol keladi, to’g’ri javob yashirilgan');
    const q1 = r.question.id;
    r = await api(users.ali, 'answer', { qid: q1, option: 1 });
    ok(r.ok && r.correct === true && r.reward === 500 && r.balance === 5500 && r.next.num === 2, 'to’g’ri javob: +500, jami 5 500, keyingi savol');
    r = await api(users.ali, 'answer', { qid: q1, option: 1 });
    ok(r.status === 400, 'bitta savolga ikki marta pul berilmaydi');
    r = await api(users.ali, 'question');
    r = await api(users.ali, 'answer', { qid: r.question.id, option: 2 });
    ok(r.ok && r.correct === false && r.reward === 0 && r.balance === 5500 && r.correctIndex === 0, 'xato javob: pul berilmaydi, keyingisiga o’tadi');
    r = await api(users.ali, 'rating?period=w');
    ok(r.ok && r.top.length === 1 && r.top[0].pts === 1 && r.me.rank === 1, 'reyting hisoblanadi');
    r = await api(users.ali, 'refs');
    ok(r.count === 1 && r.list[0].name === 'Vali' && r.earned === 5000 && r.required === 5, 'takliflarim ro’yxati');

    console.log('Admin:');
    r = await api(users.ali, 'admin/state');
    ok(r.status === 403, 'oddiy foydalanuvchi admin panelga kira olmaydi');
    r = await api(users.admin, 'admin/state');
    ok(r.ok && r.stats.users === 4 && r.questions.length === 10, 'admin statistikani ko’radi');
    r = await api(users.admin, 'admin/channel', { type: 'public', chat: '@chan' });
    ok(r.status === 400, 'bot admin bo’lmagan kanal qo’shilmaydi');
    mock.members[-1001] = { 999: 'administrator' };
    mock.members[-100200] = { 999: 'administrator' };
    r = await api(users.admin, 'admin/channel', { type: 'public', chat: 'https://t.me/chan' });
    ok(r.ok && r.channels[0].chatId === '-1001' && r.channels[0].url === 'https://t.me/chan', 'ommaviy kanal qo’shildi');
    r = await api(users.admin, 'admin/channel', { type: 'request', chat: '-100200', url: 't.me/+AbCd' });
    ok(r.ok && r.channels[1].title === 'Yopiq kanal' && r.channels[1].url === 'https://t.me/+AbCd', 'zayavka kanal qo’shildi');
    r = await api(users.admin, 'admin/channel', { type: 'link', title: 'Sayt', url: 'https://example.org' });
    ok(r.ok && r.channels.length === 3, 'oddiy havola qo’shildi');
    const linkId = r.channels[2].id;

    console.log('Pul yechish:');
    r = await api(users.ali, 'withdraw/check', {});
    ok(r.ok && r.subscribed === false && r.channels.every((c) => !c.ok), 'obuna bo’lmagan: majburiy obuna chiqadi');
    r = await api(users.ali, 'withdraw', { amount: 5000, card: '8600123412341234' });
    ok(r.status === 400, 'obunasiz pul yechib bo’lmaydi');
    mock.members[-1001][100] = 'member';
    pushUpdate({ chat_join_request: { chat: { id: -100200, type: 'channel' }, from: users.ali, date: 1 } });
    await api(users.ali, 'link-open', { id: linkId });
    await sleep(400);
    r = await api(users.ali, 'withdraw/check', {});
    ok(r.subscribed === true && r.refsOk === false && r.refCount === 1 && r.refRequired === 5, 'obuna bo’ldi → endi 5 ta do’st talab qilinadi');
    r = await api(users.admin, 'admin/settings', { rewardMin: 500, rewardMax: 500, refBonus: 6000, refRequired: 1, minWithdraw: 5000 });
    ok(r.ok && r.settings.refBonus === 6000 && r.settings.refRequired === 1, 'admin: ref soni va ref bonus o’zgartirildi');
    r = await api(users.ali, 'withdraw/check', {});
    ok(r.canWithdraw === true, 'shartlar bajarildi: pul yechish ochiq');
    r = await api(users.ali, 'withdraw', { amount: 5000, card: '8600 1234 1234 123' });
    ok(r.status === 400, 'noto’g’ri karta rad etiladi');
    r = await api(users.ali, 'withdraw', { amount: 5000, card: '8600 1234 1234 1234' });
    ok(r.ok && r.balance === 500, 'so’rov yaratildi, balansdan 5 000 ushlandi');
    await waitFor(() => sentTo(ADMIN).some((m) => m.text.includes('pul yechish')), 'adminga xabar');
    const adminMsg = sentTo(ADMIN).find((m) => m.text.includes('pul yechish'));
    ok(adminMsg.reply_markup.inline_keyboard[0][0].callback_data === 'w:pay:1', 'adminga tugmali xabar keldi');
    r = await api(users.ali, 'withdraw', { amount: 500, card: '8600123412341234' });
    ok(r.status === 400, 'kutilayotgan so’rov bor paytda yangisi ochilmaydi');
    pushUpdate({ callback_query: { id: 'c1', from: users.ali, data: 'w:pay:1', message: { message_id: 1, chat: { id: 100 }, text: 'x' } } });
    await sleep(400);
    r = await api(users.admin, 'admin/state');
    ok(r.withdrawals[0].status === 'pending', 'admin bo’lmagan odam tugmani bosa olmaydi');
    pushUpdate({ callback_query: { id: 'c2', from: users.admin, data: 'w:rej:1', message: { message_id: 1, chat: { id: ADMIN }, text: 'x' } } });
    await waitFor(() => sentTo(100).some((m) => m.text.includes('rad etildi')), 'rad xabari');
    r = await api(users.ali, 'me');
    ok(r.user.balance === 5500, 'rad etilganda pul qaytariladi');
    r = await api(users.ali, 'withdraw', { amount: 5500, card: '8600123412341234' });
    ok(r.ok && r.balance === 0, 'yangi so’rov yuborildi');
    r = await api(users.admin, 'admin/withdrawal', { id: 2, action: 'pay' });
    ok(r.ok && r.withdrawals[0].status === 'paid' && r.stats.totalPaid === 5500, 'admin paneldan «To’landi» qilindi');
    await waitFor(() => sentTo(100).some((m) => m.text.includes('o’tkazildi')), 'to’landi xabari');
    msg({ id: 400, first_name: 'Yangi' }, '/start ref_100');
    await waitFor(() => sentTo(100).some((m) => m.text.includes('Yangi') && m.text.includes('6 000 so’m')), 'yangi bonus');
    ok(true, 'yangi ref bonus (6 000) keyingi taklifga qo’llandi');

    console.log('Savollar va rasm:');
    const png = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    r = await api(users.admin, 'admin/question', { text: 'Yangi savol?', options: ['a', 'b', 'c'], correct: 2, imageData: 'data:image/png;base64,' + png });
    ok(r.ok && r.questions.length === 11 && r.questions[10].image.startsWith('/img/'), 'rasmli savol qo’shildi');
    const img = await fetch(base + r.questions[10].image);
    ok(img.status === 200 && img.headers.get('content-type') === 'image/png', 'rasm Volume’dan beriladi');
    r = await api(users.admin, 'admin/question', { id: r.questions[10].id, text: 'Tahrir?', options: ['a', 'b', 'c'], correct: 0, removeImage: true });
    ok(r.questions[10].text === 'Tahrir?' && r.questions[10].image === '', 'savol tahrirlandi, rasm olib tashlandi');
    r = await api(users.admin, 'admin/question/delete', { id: r.questions[10].id });
    ok(r.questions.length === 10, 'savol o’chirildi');
    r = await api(users.admin, 'admin/channel/delete', { id: linkId });
    ok(r.channels.length === 2, 'kanal o’chirildi');
    pushUpdate({ my_chat_member: { chat: { id: -1005, title: 'Yangi kanal', type: 'channel' }, from: users.admin, new_chat_member: { status: 'administrator', user: { id: 999 } } } });
    await waitFor(() => sentTo(ADMIN).some((m) => m.text.includes('-1005')), 'kanal ID xabari');
    ok(true, 'bot admin qilinganda kanal ID adminga yuboriladi');

    console.log('Tasodifiy mukofot:');
    r = await api(users.admin, 'admin/settings', { rewardMin: 30000, rewardMax: 10000, refBonus: 6000, refRequired: 1, minWithdraw: 5000 });
    ok(r.status === 400, 'max < min bo’lsa saqlanmaydi');
    r = await api(users.admin, 'admin/settings', { rewardMin: 10000, rewardMax: 30000, refBonus: 6000, refRequired: 1, minWithdraw: 5000 });
    ok(r.ok && r.settings.rewardMin === 10000 && r.settings.rewardMax === 30000, 'admin: mukofot 10 000 – 30 000 qilib sozlandi');
    r = await api(users.vali, 'me');
    ok(r.settings.rewardLabel === '10 000 – 30 000 so’m', 'mini app oraliqni ko’rsatadi');
    const correct = [1, 0, 2, 1, 0, 2, 0, 2, 1, 0];
    const got = [];
    let bal = 0;
    for (let i = 0; i < 10; i++) {
      const q = await api(users.vali, 'question');
      const a = await api(users.vali, 'answer', { qid: q.question.id, option: correct[i] });
      if (!a.correct) throw new Error('Namuna savol javobi mos kelmadi: ' + (i + 1));
      got.push(a.reward);
      bal += a.reward;
      if (a.balance !== bal) throw new Error('Balans noto’g’ri');
    }
    ok(got.every((x) => x >= 10000 && x <= 30000 && x % 1000 === 0), '10 ta savol: har bir mukofot 10 000–30 000 oralig’ida (' + got.join(', ') + ')');
    ok(new Set(got).size > 1, 'mukofotlar har xil (tasodifiy)');
    r = await api(users.vali, 'question');
    ok(r.done === true && r.total === 10, '10 ta savol tugagach test yakunlanadi');

    console.log('Statik fayllar:');
    let s = await fetch(base + '/');
    ok(s.status === 200 && (await s.text()).includes('app.js'), 'bosh sahifa ochiladi');
    s = await fetch(base + '/signs/stop.svg');
    ok(s.status === 200, 'belgi rasmlari beriladi');
    s = await fetch(base + '/..%2f..%2fpackage.json');
    ok(s.status !== 200, 'papkadan tashqariga chiqib bo’lmaydi');
    s = await fetch(base + '/img/..%2fdb.json');
    ok(s.status !== 200, 'db.json tashqaridan o’qilmaydi');

    console.log('Saqlanish (Volume):');
    child.kill('SIGTERM');
    await new Promise((res) => child.on('exit', res));
    ok(fs.existsSync(path.join(dataDir, 'db.json')), 'db.json Volume papkasiga yozildi');
    mock.calls.length = 0;
    startApp();
    await waitUp();
    r = await api(users.ali, 'me');
    ok(r.user.balance === 6000 && r.user.refCount === 2 && r.user.correct === 1, 'qayta ishga tushgandan keyin ma’lumotlar joyida');
    r = await api(users.ali, 'question');
    ok(r.num === 3, 'test qolgan joyidan davom etadi');

    console.log(`\nBarcha ${passed} ta sinov muvaffaqiyatli o’tdi.`);
    process.exitCode = 0;
  } catch (e) {
    console.error('\n' + e.message);
    process.exitCode = 1;
  } finally {
    if (child && child.exitCode === null) child.kill('SIGKILL');
    mockServer.close();
    fs.rmSync(dataDir, { recursive: true, force: true });
    setTimeout(() => process.exit(process.exitCode), 200);
  }
})();
